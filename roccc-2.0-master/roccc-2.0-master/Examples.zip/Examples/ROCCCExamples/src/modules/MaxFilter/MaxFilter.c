
void MAX(int A0_in, int A1_in, int A2_in, int& max_out)
{
  int tmp1 ;

  if (A0_in > A1_in)
  {
    tmp1 = A0_in ;
  }
  else
  {
    tmp1 = A1_in ;
  }

  if (tmp1 > A2_in)
  {
    max_out = tmp1 ;
  }
  else
  {
    max_out = A2_in ;
  }  
}

