
#include "roccc-library.h"

void CompleteMDFloat(float atomOneCurrentX_in, float atomOneCurrentY_in, float atomOneCurrentZ_in, float atomOneCurrentCharge_in,
		                float atomTwoCurrentX_in, float atomTwoCurrentY_in, float atomTwoCurrentZ_in, float atomTwoCurrentCharge_in,
		                float currentConstant12_in, float currentConstant6_in, float tableLookup_in,
		                float& VanDerWaalEnergy_out,
		                float& CoulombicForceX_out,
		                float& CoulombicForceY_out,
		                float& CoulombicForceZ_out)
{
  float twelfthTerm ;
  float sixthTerm ;
  float radiusToTheTwelfth ;
  float radiusToTheSixth ;
  float radiusSquared ;
  float distanceXSquared ;
  float differenceX ;
  float distanceYSquared ;
  float differenceY ;
  float distanceZSquared ;
  float differenceZ ;

  // Call the Coulombic force module
  MDFloat(atomOneCurrentX_in,
		     atomOneCurrentY_in,
		     atomOneCurrentZ_in, 
		     atomOneCurrentCharge_in, 
		     atomTwoCurrentX_in, 
		     atomTwoCurrentY_in, 
		     atomTwoCurrentZ_in, 
		     atomTwoCurrentCharge_in, 
		     tableLookup_in, 
		     CoulombicForceX_out, 
		     CoulombicForceY_out, 
		     CoulombicForceZ_out);

  // Perform the calculations for the VanDerWaal Energy

  differenceX = atomOneCurrentX_in - atomTwoCurrentX_in ;
  differenceY = atomOneCurrentY_in - atomTwoCurrentY_in ;
  differenceZ = atomOneCurrentZ_in - atomTwoCurrentZ_in ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;
  
  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  radiusToTheSixth = radiusSquared * radiusSquared * radiusSquared ;
  radiusToTheTwelfth = radiusToTheSixth * radiusToTheSixth ;

  twelfthTerm = currentConstant12_in * radiusToTheTwelfth ;
  sixthTerm = currentConstant6_in * radiusToTheSixth ;

  VanDerWaalEnergy_out = twelfthTerm - sixthTerm ;

}
