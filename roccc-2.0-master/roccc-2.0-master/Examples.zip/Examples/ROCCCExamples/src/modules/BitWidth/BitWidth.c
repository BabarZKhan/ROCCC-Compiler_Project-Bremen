// To declare a variable of a different bit size, you must define a typedef
//  of the form ROCCC_intX, where X is the size in bits you wish it to be.
//  Floating point values may only be 16, 32, or 64 bits.

typedef int ROCCC_int23 ;
typedef int ROCCC_int14 ;
typedef int ROCCC_int31 ;
typedef int ROCCC_int7 ;
typedef int ROCCC_int5 ;

void BitWidth(ROCCC_int23 A_in, ROCCC_int14 B_in, ROCCC_int31 C_in, 
	      ROCCC_int7 D_in, ROCCC_int5& Final_out) 
{
	Final_out = (A_in * B_in) - (C_in / D_in) + 10 ;
}
