// This module requires the user to import a square root core named SQRT
//  that takes a floating point value and returns a floating point value.
#include "roccc-library.h"

typedef float ROCCC_float32 ;
typedef int ROCCC_int1 ;

void QuadraticFormula(ROCCC_float32 a_in, ROCCC_float32 b_in, ROCCC_float32 c_in,
		      ROCCC_float32& x1Real_out, ROCCC_float32& x1Imag_out,
		      ROCCC_float32& x2Real_out, ROCCC_float32& x2Imag_out,
		      ROCCC_int1& infinity_out)
{
	ROCCC_float32 sqrtValue ;
	ROCCC_float32 bSquaredMinusFourAC ;
	ROCCC_float32 twoA ;
	
	ROCCC_float32 tempReal1 ;
	ROCCC_float32 tempImag1 ;
	ROCCC_float32 tempReal2 ;
	ROCCC_float32 tempImag2 ;

	ROCCC_int1 tempInfinity ;
	
	// If A is zero, it is not quadratic thus you get division by zero
	if (a_in == 0)
	{
		tempReal1 = 0 ;
		tempImag1 = 0 ;
		tempReal2 = 0 ;
		tempImag2 = 0 ;
		
		tempInfinity = 1 ;
	}
	else
	{
		bSquaredMinusFourAC = b_in * b_in - 4 * a_in * c_in ;
		twoA = 2 * a_in ;
		
		// If the inside of the square root is negative, then you get
		//  imaginary numbers
		if (bSquaredMinusFourAC >= 0)
		{
			SQRT(bSquaredMinusFourAC, sqrtValue) ; // SQRT must exist in the database
			tempReal1 = -b_in + sqrtValue / twoA ;
			tempReal2 = -b_in - sqrtValue / twoA ;

			tempImag1 = 0 ;
			tempImag2 = 0 ;
		}
		else
		{
			tempReal1 = -b_in / twoA ;
			tempReal2 = tempReal1 ;
			
			SQRT(-bSquaredMinusFourAC, sqrtValue) ;
			
			tempImag1 = sqrtValue / twoA ;
			tempImag2 = -tempImag1 ; 
		}
		tempInfinity = 0 ;
	}
	x1Real_out = tempReal1 ;
	x1Imag_out = tempImag1 ;
	x2Real_out = tempReal2 ;
	x2Imag_out = tempImag2 ;
	
	infinity_out = tempInfinity ;
}
