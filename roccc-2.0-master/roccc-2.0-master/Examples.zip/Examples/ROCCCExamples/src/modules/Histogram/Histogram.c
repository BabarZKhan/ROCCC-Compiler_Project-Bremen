/*

  This component represents one stage in a hardware histogram circuit.
    Each stage is responsible for keeping track of one value as a large
    data set is streamed through, with the output of one stage leading directly
    into another.

*/

// The way this histogram block works is every block is initialized with a 
//  value of 0 and a count of 0.  If the count is 0, grab the first value 
//  you see on the input stream and store it.  On all subsequent input values, 
//  check to see if the value is the same as the stored value.

void Histogram(int Count_in, int Value_in, int Input_in, int Valid_in,
	       int& Count_out, int& Value_out, int& Stream_out, int& Valid_out)
{
  int Tmp1 ;
  Tmp1 = (Count_in == 0) & (Valid_in == 1) ;
  if (Tmp1)
  {
    Value_out = Input_in ;
  }
  else
  {
    Value_out = Value_in ;
  }
  if (Tmp1 | ((Valid_in == 1) & (Value_in == Input_in)))
  {
    Count_out = Count_in + 1 ;
  }
  else
  {
    Count_out = Count_in ;
  }
  if (Tmp1 | ((Valid_in == 1) & (Value_in == Input_in)))
  {
    Valid_out = 0 ;
  }
  else
  {
    Valid_out = Valid_in ;
  }
  if (Tmp1 | ((Valid_in == 1) & (Value_in == Input_in)))
  {
    Stream_out = 0 ;
  }
  else
  {
    Stream_out = Input_in ;
  }
}
