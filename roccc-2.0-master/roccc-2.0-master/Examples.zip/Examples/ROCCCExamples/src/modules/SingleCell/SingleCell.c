// This will be used in the Smith-Waterman systolic array example
typedef int ROCCC_int2 ;
typedef int ROCCC_int8 ;

void SingleCell(ROCCC_int8 S_in, ROCCC_int8 T_in, ROCCC_int8 upper_in, ROCCC_int8 upperLeft_in,
		ROCCC_int8 left_in,  ROCCC_int8& current_out)
{
  const int matchCost = 4 ;
  const int mismatchCost = 3 ;
  const int insertCost = 2 ;
  const int deleteCost = 1 ;

  ROCCC_int8 intermediate0 ;
  ROCCC_int8 intermediate1 ;

  if (S_in == T_in)
  {
    intermediate0 = upperLeft_in + matchCost ;
  }
  else
  {
    intermediate0 = upperLeft_in + mismatchCost ;
  }

  if (upper_in + insertCost > left_in + deleteCost)
  {
    intermediate1 = upper_in + insertCost ;
  }
  else
  {
    intermediate1 = left_in + deleteCost ;
  }

  if (intermediate0 > intermediate1)
  {
    current_out = intermediate0 ;
  }
  else
  {
    current_out = intermediate1 ;
  }

}
