/*

  This example exists only to show that modules can have loops if they
   are fully unrolled.  The loops will be fully unrolled automatically.

*/

void LoopTest(int x_in, int& y_out)
{
  int i ;
  int currentSum ;
  int A[10] ;
  
  currentSum = 0 ;

 L1: for (i = 0 ; i < 10 ; ++i)
  {
    A[i] = i ;
  }

 L2: for (i = 0 ; i < 10 ; ++i)
  {
    if (x_in == A[i])
    {
      currentSum = currentSum + A[i] ;
    }
    else
    {
      currentSum = currentSum + 1 ;
    }
  }
  
  y_out = currentSum + x_in ;

}
