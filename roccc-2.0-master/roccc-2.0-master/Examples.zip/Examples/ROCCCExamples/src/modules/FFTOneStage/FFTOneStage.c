#include "roccc-library.h"

void FFTOneStage(int real0_in, int imag0_in,
		            int real1_in, int imag1_in,
		            int real2_in, int imag2_in,
		            int real3_in, int imag3_in,
		            int real4_in, int imag4_in,
		            int real5_in, int imag5_in,
		            int real6_in, int imag6_in,
		            int real7_in, int imag7_in,
		            int realOmega_in, int imagOmega_in,
		            int& x0Real_out, int& x0Imag_out, 
		            int& x1Real_out, int& x1Imag_out, 
		            int& x2Real_out, int& x2Imag_out, 
		            int& x3Real_out, int& x3Imag_out, 
		            int& x4Real_out, int& x4Imag_out, 
		            int& x5Real_out, int& x5Imag_out, 
		            int& x6Real_out, int& x6Imag_out, 
		            int& x7Real_out, int& x7Imag_out)
{

  // There are four butterfly operations per stage.
  FFT(real0_in, 
		 imag0_in, 
		 real1_in, 
		 imag1_in, 
		 realOmega_in, 
		 imagOmega_in, 
		 x0Real_out, 
		 x0Imag_out, 
		 x1Real_out, 
		 x1Imag_out);

  FFT(real2_in, 
		 imag2_in, 
		 real3_in, 
		 imag3_in, 
		 realOmega_in, 
		 imagOmega_in, 
		 x2Real_out, 
		 x2Imag_out, 
		 x3Real_out, 
		 x3Imag_out);

  FFT(real4_in, 
		 imag4_in, 
		 real5_in, 
		 imag5_in, 
		 realOmega_in, 
		 imagOmega_in, 
		 x4Real_out, 
		 x4Imag_out, 
		 x5Real_out, 
		 x5Imag_out);
  
  FFT(real6_in, 
		 imag6_in, 
		 real7_in, 
		 imag7_in, 
		 realOmega_in, 
		 imagOmega_in, 
		 x6Real_out, 
		 x6Imag_out, 
		 x7Real_out, 
		 x7Imag_out);

}
