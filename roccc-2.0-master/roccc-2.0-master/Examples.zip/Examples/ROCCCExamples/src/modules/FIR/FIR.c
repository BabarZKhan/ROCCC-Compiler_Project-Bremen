/*

  A five-tap FIR filter.  

*/

void FIR(int A0_in, int A1_in, int A2_in, int A3_in, int A4_in, int& result_out)
{
  // Should be propagated
  const int T[5] = { 3, 5, 7, 9, 11 } ;
  
  result_out = A0_in * T[0] +
    A1_in * T[1] +
    A2_in * T[2] +
    A3_in * T[3] +
    A4_in * T[4] ;

}
