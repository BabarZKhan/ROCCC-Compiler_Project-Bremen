void Pow10(int x_in, int& y_out)
{
  int total ;
  int i ;
  total = 1; 
  for (i = 0 ; i < 10 ; ++i)
  {
    total *= x_in ;
  }
  y_out = total ;
}
