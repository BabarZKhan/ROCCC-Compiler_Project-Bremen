
#include "roccc-library.h"

void CompleteMD(int atomOneCurrentX_in, int atomOneCurrentY_in, int atomOneCurrentZ_in, int atomOneCurrentCharge_in,
		        int atomTwoCurrentX_in, int atomTwoCurrentY_in, int atomTwoCurrentZ_in, int atomTwoCurrentCharge_in,
		        int currentConstant12_in, int currentConstant6_in, int tableLookup_in,
		        int& VanDerWaalEnergy_out, int& CoulombicForceX_out, int& CoulombicForceY_out,
		        int& CoulombicForceZ_out)
{
  int twelfthTerm ;
  int sixthTerm ;
  int radiusToTheTwelfth ;
  int radiusToTheSixth ;
  int radiusSquared ;
  int distanceXSquared ;
  int differenceX ;
  int distanceYSquared ;
  int differenceY ;
  int distanceZSquared ;
  int differenceZ ;

  // Call the Coulombic force module
  MD(atomOneCurrentX_in, 
     atomOneCurrentY_in, 
     atomOneCurrentZ_in, 
     atomOneCurrentCharge_in, 
     atomTwoCurrentX_in, 
     atomTwoCurrentY_in, 
     atomTwoCurrentZ_in, 
     atomTwoCurrentCharge_in, 
     tableLookup_in, 
     CoulombicForceX_out, 
     CoulombicForceY_out, 
     CoulombicForceZ_out);
  
  // Perform the calculations for the VanDerWaal Energy

  differenceX = atomOneCurrentX_in - atomTwoCurrentX_in ;
  differenceY = atomOneCurrentY_in - atomTwoCurrentY_in ;
  differenceZ = atomOneCurrentZ_in - atomTwoCurrentZ_in ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;
  
  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  radiusToTheSixth = radiusSquared * radiusSquared * radiusSquared ;
  radiusToTheTwelfth = radiusToTheSixth * radiusToTheSixth ;

  twelfthTerm = currentConstant12_in * radiusToTheTwelfth ;
  sixthTerm = currentConstant6_in * radiusToTheSixth ;

  VanDerWaalEnergy_out = twelfthTerm - sixthTerm ;

}
