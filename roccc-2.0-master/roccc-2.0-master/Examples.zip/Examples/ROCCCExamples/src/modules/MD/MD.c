
void MD(int atomOneCurrentX_in, int atomOneCurrentY_in, int atomOneCurrentZ_in, int atomOneCurrentCharge_in,
	int atomTwoCurrentX_in, int atomTwoCurrentY_in, int atomTwoCurrentZ_in, int atomTwoCurrentCharge_in,
	int tableLookup_in, int& CoulombicForceX_out, int& CoulombicForceY_out, int& CoulombicForceZ_out) 
{
  int twelfthTerm ;
  int sixthTerm ;
  int radiusToTheTwelfth ;
  int radiusToTheSixth ;
  int radiusSquared ;
  int distanceXSquared ;
  int distanceYSquared ;
  int distanceZSquared ;
  int differenceX ;
  int differenceY ;
  int differenceZ ;
  int vcoul ;
  int rinvsq ;
  int rinv ;

  differenceX = atomOneCurrentX_in - atomTwoCurrentX_in ;
  differenceY = atomOneCurrentY_in - atomTwoCurrentY_in ;
  differenceZ = atomOneCurrentZ_in - atomTwoCurrentZ_in ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;

  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  
  rinv = (tableLookup_in * (((radiusSquared * tableLookup_in) * tableLookup_in))) ;

  vcoul = atomOneCurrentCharge_in * atomTwoCurrentCharge_in * rinv ;

  rinvsq = rinv * rinv ;

  CoulombicForceX_out = vcoul * rinvsq * differenceX ;
  CoulombicForceY_out = vcoul * rinvsq * differenceY ;
  CoulombicForceZ_out = vcoul * rinvsq * differenceZ ;
}
