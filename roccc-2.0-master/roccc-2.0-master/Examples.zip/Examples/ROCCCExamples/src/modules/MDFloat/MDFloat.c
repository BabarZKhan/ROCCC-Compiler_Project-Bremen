void MDFloat(float atomOneCurrentX_in, float atomOneCurrentY_in, float atomOneCurrentZ_in, float atomOneCurrentCharge_in,
		        float atomTwoCurrentX_in, float atomTwoCurrentY_in, float atomTwoCurrentZ_in, float atomTwoCurrentCharge_in,
		        float tableLookup_in, float& CoulombicForceX_out, float& CoulombicForceY_out,
		        float& CoulombicForceZ_out)
{
  float twelfthTerm ;
  float sixthTerm ;
  float radiusToTheTwelfth ;
  float radiusToTheSixth ;
  float radiusSquared ;
  float distanceXSquared ;
  float distanceYSquared ;
  float distanceZSquared ;
  float differenceX ;
  float differenceY ;
  float differenceZ ;
  float vcoul ;
  float rinvsq ;
  float rinv ;

  differenceX = atomOneCurrentX_in - atomTwoCurrentX_in ;
  differenceY = atomOneCurrentY_in - atomTwoCurrentY_in ;
  differenceZ = atomOneCurrentZ_in - atomTwoCurrentZ_in ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;

  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  
  rinv = (tableLookup_in * (((radiusSquared * tableLookup_in) * tableLookup_in))) ;

  vcoul = atomOneCurrentCharge_in * atomTwoCurrentCharge_in * rinv ;

  rinvsq = rinv * rinv ;

  CoulombicForceX_out = vcoul * rinvsq * differenceX ;
  CoulombicForceY_out = vcoul * rinvsq * differenceY ;
  CoulombicForceZ_out = vcoul * rinvsq * differenceZ ;
}
