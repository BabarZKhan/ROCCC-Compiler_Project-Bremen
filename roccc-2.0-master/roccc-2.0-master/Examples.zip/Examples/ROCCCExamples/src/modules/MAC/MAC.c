/*

  This file represents a small multiply-accumulate component.

*/

void MAC(int num1_in, int num2_in, int num3_in, int& sum_out)
{
  sum_out = (num1_in * num2_in) + num3_in ;
}
