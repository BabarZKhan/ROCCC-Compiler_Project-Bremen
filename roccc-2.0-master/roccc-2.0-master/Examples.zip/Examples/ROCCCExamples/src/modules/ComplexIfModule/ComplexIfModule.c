// This example doesn't perform any substantial computation but exists to
//  show the types of if structures that are supported by ROCCC and the
//  hardware generated when using such structures.

#include "roccc-library.h"

void ComplexIfModule(int x_in, int y_in, int z_in, int& final_out)
{
  int temp ;
  int temp2 ;

  if (x_in != y_in)
  {
    temp = z_in ;
    temp = temp + 5 ;
  }
  else
  {
    if (z_in == 15)
    {
      MAX(x_in, y_in, z_in, temp2) ;
    }
    else
    {
      MAX(y_in, z_in, x_in, temp2) ;
    }
  }

  final_out = temp + temp2 ;
}

