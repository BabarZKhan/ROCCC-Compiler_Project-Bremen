/*

  This is the basic block for the FFT.  It takes two numbers (each of which 
    has a real and imaginary part) and an omega that is different at each
    stage in the butterfly.

*/
typedef int ROCCC_int32 ;

void FFT(ROCCC_int32 realOne_in, ROCCC_int32 imagOne_in, 
	 ROCCC_int32 realTwo_in, ROCCC_int32 imagTwo_in, 
	 ROCCC_int32 realOmega_in, ROCCC_int32 imagOmega_in,
	 ROCCC_int32& A0_out, ROCCC_int32& A1_out, ROCCC_int32& A2_out, ROCCC_int32& A3_out)
{

  A0_out = realOne_in + (realOmega_in * realTwo_in) - 
           (imagOmega_in * imagTwo_in) ;

  A1_out = imagOne_in + (realOmega_in * imagTwo_in) + 
           (imagOmega_in * realTwo_in) ;

  A2_out = realOne_in - (realOmega_in * realTwo_in) + 
            (imagOmega_in * imagTwo_in) ;

  A3_out = imagOne_in - (realOmega_in * imagTwo_in) - 
           (imagOmega_in * realTwo_in) ;

}
