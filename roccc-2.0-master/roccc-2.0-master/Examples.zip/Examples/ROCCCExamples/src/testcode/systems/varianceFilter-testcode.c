#include <stdio.h>
#include <assert.h>

const int sizeOfInput = 1000 ;

void VarianceFilter(char* inputStream, char* outputStream)
{

  int i ;

  int accum ;
  int accum2 ;
  int xBar ;
  int sigmaSquared ;
  int finalValue ;

  const int threshold = 500 ; // Some constant value...

  // Calculate X-bar first
  for (i = 0 ; i < sizeOfInput; i+=20)
    {
      accum = inputStream[i] + inputStream[i+1] ;
      accum += inputStream[i+2] ;
      accum += inputStream[i+3] ;
      accum += inputStream[i+4] ;
      accum += inputStream[i+5] ;
      accum += inputStream[i+6] ;
      accum += inputStream[i+7] ;
      accum += inputStream[i+8] ;
      accum += inputStream[i+9] ;
      accum += inputStream[i+10] ;
      accum += inputStream[i+11] ;
      accum += inputStream[i+12] ;
      accum += inputStream[i+13] ;
      accum += inputStream[i+14] ;
      accum += inputStream[i+15] ;
      accum += inputStream[i+16] ;
      accum += inputStream[i+17] ;
      accum += inputStream[i+18] ;
      accum += inputStream[i+19] ;

      xBar = accum / 20 ;

      // Now calculate sigma squared

      accum2 = (inputStream[i] - xBar) * (inputStream[i] - xBar) ;
      accum2 += (inputStream[i+1] - xBar) * (inputStream[i+1] - xBar) ;
      accum2 += (inputStream[i+2] - xBar) * (inputStream[i+2] - xBar) ;
      accum2 += (inputStream[i+3] - xBar) * (inputStream[i+3] - xBar) ;
      accum2 += (inputStream[i+4] - xBar) * (inputStream[i+4] - xBar) ;
      accum2 += (inputStream[i+5] - xBar) * (inputStream[i+5] - xBar) ;
      accum2 += (inputStream[i+6] - xBar) * (inputStream[i+6] - xBar) ;
      accum2 += (inputStream[i+7] - xBar) * (inputStream[i+7] - xBar) ;
      accum2 += (inputStream[i+8] - xBar) * (inputStream[i+8] - xBar) ;
      accum2 += (inputStream[i+9] - xBar) * (inputStream[i+9] - xBar) ;
      accum2 += (inputStream[i+10] - xBar) * (inputStream[i+10] - xBar) ;
      accum2 += (inputStream[i+11] - xBar) * (inputStream[i+11] - xBar) ;
      accum2 += (inputStream[i+12] - xBar) * (inputStream[i+12] - xBar) ;
      accum2 += (inputStream[i+13] - xBar) * (inputStream[i+13] - xBar) ;
      accum2 += (inputStream[i+14] - xBar) * (inputStream[i+14] - xBar) ;
      accum2 += (inputStream[i+15] - xBar) * (inputStream[i+15] - xBar) ;
      accum2 += (inputStream[i+16] - xBar) * (inputStream[i+16] - xBar) ;
      accum2 += (inputStream[i+17] - xBar) * (inputStream[i+17] - xBar) ;
      accum2 += (inputStream[i+18] - xBar) * (inputStream[i+18] - xBar) ;
      accum2 += (inputStream[i+19] - xBar) * (inputStream[i+19] - xBar) ;

      sigmaSquared = accum2 / 20 ;

      // Output in chunks of 20
      if (sigmaSquared > threshold)
	{
	  finalValue = 0 ;
	}
      else
	{
	  finalValue = inputStream[i] ;
	}

      outputStream[i] = finalValue ;

    }
}

int main()
{
  char inputStream[1000] ;
  char outputStream[1000] ;
  int i ;

  // initialize both
  for (i = 0 ; i < 1000 ; ++i)
  {
    inputStream[i] = i % 32 + i / ((i % 3) + 1) ;
    outputStream[i] = 0 ;
  }
  
  VarianceFilter(inputStream, outputStream) ;

  FILE* streamI = fopen("./inputStream", "w") ;
  FILE* streamO = fopen("./outputStream", "w") ;
  assert(streamI != NULL) ;
  assert(streamO != NULL) ;

  for (i = 0 ; i < 1000 ; ++i)
  {
    fprintf(streamI, "%d ", inputStream[i]) ;
  }
  fprintf(streamI, "\n") ;

  for (i = 0 ; i < 1000 ; i+=20)
  {
    fprintf(streamO, "%d ", outputStream[i]) ;
  }
  fprintf(streamO, "\n") ;

  fclose(streamI) ;
  fclose(streamO) ;

  return 0 ;
}
