#include <stdio.h>
#include <assert.h>

void FIR(int A0, int A1, int A2, int A3, int A4, int& result)
{
  const int T[5] = { 3, 5, 7, 9, 11 } ;
  result = A0 * T[0] + A1 * T[1] + A2 * T[2] + A3 * T[3] + A4 * T[4] ;
}


void FIRSystem(int* A, int* B)
{
  int i ;
  int myTmp ;
  for(i = 0 ; i < 100 ; ++i)
  {
    FIR(A[i], A[i+1], A[i+2], A[i+3], A[i+4], myTmp) ;
    B[i] = myTmp ;
  }
}

int main()
{
  
  int A[105] ;
  int B[100] ;

  int i ;

  for (i = 0 ; i < 105 ; ++i)
  {
    A[i] = (i % 32) + i / (i % 3 + 1) ;
  }

  FIRSystem(A, B) ;

  FILE* streamA = fopen("./streamA", "w") ;
  FILE* streamB = fopen("./streamB", "w") ;
  
  assert(streamA != NULL) ;
  assert(streamB != NULL) ;

  for (i = 0 ; i < 105 ; ++i)
  {
    fprintf(streamA, "%d ", A[i]) ;
  }
  fprintf(streamA, "\n") ;

  for (i = 0 ; i < 100 ; ++i)
  {
    fprintf(streamB, "%d ", B[i]) ;
  }
  fprintf(streamB, "\n") ;

  fclose(streamA) ;
  fclose(streamB) ;

  return 0 ;
}
