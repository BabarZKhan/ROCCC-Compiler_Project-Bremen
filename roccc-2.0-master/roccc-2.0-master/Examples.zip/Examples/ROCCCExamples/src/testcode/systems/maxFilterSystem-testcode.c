#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

void MAX(int A0, int A1, int A2, int& max)
{
  int tmp1 ; 
  if (A0 > A1)
  {
    tmp1 = A0 ;
  }
  else
  {
    tmp1 = A1 ;
  }
  if (tmp1 > A2) 
  {
    max = tmp1 ;
  }
  else
  {
    max = A2 ;
  }
}

void MaxFilterSystem(int window[13][13], int height, int width, 
		     int& finalOutput)
{
  int maxCol1 ;
  int maxCol2 ;
  int maxCol3 ;

  int i ; 
  int j ;

  for (i = 0 ; i< height ; ++i)
  {
    for (j = 0 ; j < width ; ++j)
    {
      MAX(window[i][j], window[i][j+1], window[i][j+2], maxCol1) ;
      MAX(window[i+1][j], window[i+1][j+1], window[i+1][j+2], maxCol2) ;
      MAX(window[i+2][j], window[i+2][j+1], window[i+2][j+2], maxCol3) ;

      // Find the maximium of the three columns
      MAX(maxCol1, maxCol2, maxCol3, finalOutput) ;
    }
  }
}

int main()
{
  int window[13][13] ;
  int height = 10 ; 
  int width = 10 ;
  int finalOutput ;

  int i ;
  int j ;

  // Initialize
  for (i = 0 ; i < 13 ; ++i)
  {
    for (j = 0 ; j < 13 ; ++j)
    {
      window[i][j] = i + j ;
    }
  }

  MaxFilterSystem(window, height, width, finalOutput) ;

  FILE* windowStream = fopen("./window", "w") ;
  assert(windowStream != NULL) ;
  
  for (i = 0 ; i < 13 ; ++i)
  {
    for (j = 0 ; j < 13 ; ++j)
    {
      fprintf(windowStream, "%d ", window[i][j]) ;
    }
    fprintf(windowStream, "\n") ;
  }

  printf("finalOutput: %d\n", finalOutput) ;

  fclose(windowStream) ;

  return 0 ;
}
