#include <stdio.h>
#include <assert.h>

void MatrixMultiplication(int A[10][10], int B[10][10], int C0[10][10][1])
{
  int i ;
  int j ;
  int k ;
  int currentSum ;
  
  for (i = 0 ; i < 10 ; ++i)
  {
    for (j = 0 ; j < 10 ;  ++j)
    {
      for (k = 0 ; k < 1 ; ++k)
      {
	currentSum = 0 ;
	currentSum += A[i][k] * B[k][j] ;
	currentSum += A[i][k+1] * B[k+1][j] ;
	currentSum += A[i][k+2] * B[k+2][j] ;
	currentSum += A[i][k+3] * B[k+3][j] ;
	currentSum += A[i][k+4] * B[k+4][j] ;
	currentSum += A[i][k+5] * B[k+5][j] ;
	currentSum += A[i][k+6] * B[k+6][j] ;
	currentSum += A[i][k+7] * B[k+7][j] ;
	currentSum += A[i][k+8] * B[k+8][j] ;
	currentSum += A[i][k+9] * B[k+9][j] ;
	C0[i][j][k] = currentSum ;
      }
    }
  }
}

int main()
{
  int A[10][10] ;
  int B[10][10] ;
  int C[10][10][1] ;
  
  int i ;
  int j ;
  int k ;

  // Initialize
  for (i = 0 ; i < 10 ; ++i)
  {
    for (j = 0 ; j < 10 ; ++j)
    {
      A[i][j] = (i + j) ; // % 32 + ((i + j) / (((i + j) % 3) + 1)) ;
      B[i][j] = (i - j) ; // % 32 + ((i - j) / (((i - j) % 3) + 1)) ;
    }
  }

  MatrixMultiplication(A, B, C) ;

  FILE* streamA = fopen("./streamA", "w") ;
  FILE* streamB = fopen("./streamB", "w") ;
  FILE* streamC = fopen("./streamC", "w") ;

  assert(streamA != NULL) ;
  assert(streamB != NULL) ;
  assert(streamC != NULL) ;

  for (i = 0 ; i < 10 ; ++i)
  {
    for(j = 0 ; j < 10 ; ++j)
    {
      fprintf(streamA, "%d ", A[i][j]) ;
      fprintf(streamB, "%d ", B[i][j]) ;
    }
    fprintf(streamA, "\n") ;
    fprintf(streamB, "\n") ;
  }

  for (i = 0 ; i < 10 ; ++i)
  {
    for (j = 0 ; j < 10 ; ++j)
    {
      for (k = 0 ; k < 1 ; ++k)
      {
	fprintf(streamC, "%d ", C[i][j][k]) ;
      }
    }
    fprintf(streamC, "\n") ;
  }

  fclose(streamA) ;
  fclose(streamB) ;
  fclose(streamC) ;

  return 0 ;
}
