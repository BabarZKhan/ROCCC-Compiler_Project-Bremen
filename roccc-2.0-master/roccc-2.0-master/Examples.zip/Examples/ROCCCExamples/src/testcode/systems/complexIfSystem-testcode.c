#include <stdio.h>
#include <assert.h>

void MAX(int A0_in, int A1_in, int A2_in, int& max_out)
{
  int tmp1 ;
  if (A0_in > A1_in) 
  {
    tmp1 = A0_in ;
  }
  else
  {
    tmp1 = A1_in ;
  }
  if (tmp1 > A2_in)
  {
    max_out = tmp1 ;
  }
  else
  {
    max_out = A2_in ;
  }
}

void ComplexIfSystem(int* A, int* B)
{
  int i ; 
  int temp ;
  int temp2 ;

  temp = 0 ; 
  temp2 = 0 ;

  for (i = 0 ; i < 100 ; ++i)
  {
    if (A[i] != A[i+1])
    {
      temp = A[i+2] ;
      temp = temp + 5 ;
      temp = (temp2 / 15) + temp ;
    }
    else
    {
      if (A[i+1] == 15)
      {
	MAX(A[i], A[i+1], A[i+2], temp2) ;
      }
      else
      {
	MAX(A[i+1], A[i+2], A[i], temp2) ;
      }
      temp = temp2 * 15 ;
    }
    B[i] = temp2 + temp ;
  }
}

int main()
{
  int A[102] ;
  int B[100] ;
  int i ;

  // Initialize A
  for (i = 0 ; i < 102 ;++i)
  {
    A[i] = i % 16 ;
  }

  ComplexIfSystem(A, B) ;
  
  FILE* streamA = fopen("./streamA", "w") ;
  assert(streamA != NULL) ;

  for (i = 0 ; i < 102 ; ++i)
  {
    fprintf(streamA, "%d ", A[i]) ;
  }
  fprintf(streamA, "\n") ;

  FILE* streamB = fopen("./streamB", "w") ;
  assert(streamB != NULL) ;
  for (i = 0 ; i < 100 ; ++i)
  {
    fprintf(streamB, "%d ", B[i]) ;
  }
  fprintf(streamB, "\n") ;

  fclose(streamA) ;
  fclose(streamB) ;
  return 0 ;
}
