#include <stdio.h>

void FFT(int realOne, int imagOne, int realTwo, int imagTwo,
	 int realOmega, int imagOmega, 
	 int& A0_out, int& A1_out, int& A2_out, int& A3_out)
{
  A0_out = realOne + (realOmega * realTwo) - (imagOmega * imagTwo) ;
  A1_out = imagOne + (realOmega * imagTwo) + (imagOmega * realTwo) ;
  A2_out = realOne - (realOmega * realTwo) + (imagOmega * imagTwo) ;
  A3_out = imagOne - (realOmega * imagTwo) - (imagOmega * realTwo) ;
}

int main()
{
  int A0 ;
  int A1 ;
  int A2 ;
  int A3 ;

  FFT(1, 1, 1, 1, 1, 1, A0, A1, A2, A3) ;
  printf("--- Test case 1 ---\n") ;
  printf("realOne: %d\n", 1) ;
  printf("imagOne: %d\n", 1) ;
  printf("realTwo: %d\n", 1) ;
  printf("imagTwo: %d\n", 1) ;
  printf("realOmega: %d\n", 1) ;
  printf("imagOmega: %d\n", 1) ;
  printf("A0: %d\n", A0) ;
  printf("A1: %d\n", A1) ;
  printf("A2: %d\n", A2) ;
  printf("A3: %d\n", A3) ;
  printf("\n") ;

  FFT(2, 0, -1, 0, 4, 0, A0, A1, A2, A3) ;
  printf("--- Test case 2 ---\n") ;
  printf("realOne: %d\n", 2) ;
  printf("imagOne: %d\n", 0) ;
  printf("realTwo: %d\n", -1) ;
  printf("imagTwo: %d\n", 0) ;
  printf("realOmega: %d\n", 4) ;
  printf("imagOmega: %d\n", 0) ;
  printf("A0: %d\n", A0) ;
  printf("A1: %d\n", A1) ;
  printf("A2: %d\n", A2) ;
  printf("A3: %d\n", A3) ;
  printf("\n") ;

  FFT(1, 2, 3, 4, 5, 6, A0, A1, A2, A3) ;
  printf("--- Test case 3 ---\n") ;
  printf("realOne: %d\n", 1) ;
  printf("imagOne: %d\n", 2) ;
  printf("realTwo: %d\n", 3) ;
  printf("imagTwo: %d\n", 4) ;
  printf("realOmega: %d\n", 5) ;
  printf("imagOmega: %d\n", 6) ;
  printf("A0: %d\n", A0) ;
  printf("A1: %d\n", A1) ;
  printf("A2: %d\n", A2) ;
  printf("A3: %d\n", A3) ;
  printf("\n") ;

  FFT(1, -1, 1, -1, 1, -1, A0, A1, A2, A3) ;
  printf("--- Test case 4 ---\n") ;
  printf("realOne: %d\n", 1) ;
  printf("imagOne: %d\n", -1) ;
  printf("realTwo: %d\n", 1) ;
  printf("imagTwo: %d\n", -1) ;
  printf("realOmega: %d\n", 1) ;
  printf("imagOmega: %d\n", -1) ;
  printf("A0: %d\n", A0) ;
  printf("A1: %d\n", A1) ;
  printf("A2: %d\n", A2) ;
  printf("A3: %d\n", A3) ;
  printf("\n") ;


  return 0 ;
}
