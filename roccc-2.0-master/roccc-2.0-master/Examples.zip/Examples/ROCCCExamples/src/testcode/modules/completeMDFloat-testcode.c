#include <stdio.h>

void MDFloat(float atomOneCurrentX, float atomOneCurrentY, 
	     float atomOneCurrentZ, float atomOneCurrentCharge,
	     float atomTwoCurrentX, float atomTwoCurrentY, 
	     float atomTwoCurrentZ, float atomTwoCurrentCharge,
	     float tableLookup, float& CoulombicForceX, 
	     float& CoulombicForceY, float& CoulombicForceZ)
{
  float radiusSquared ;
  float distanceXSquared ;
  float distanceYSquared ;
  float distanceZSquared ;
  float differenceX ;
  float differenceY ;
  float differenceZ ;
  float vcoul ;
  float rinvsq ;
  float rinv ;

  differenceX = atomOneCurrentX - atomTwoCurrentX ;
  differenceY = atomOneCurrentY - atomTwoCurrentY ;
  differenceZ = atomOneCurrentZ - atomTwoCurrentZ ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;

  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  
  rinv = (tableLookup * (((radiusSquared * tableLookup) * tableLookup))) ;

  vcoul = atomOneCurrentCharge * atomTwoCurrentCharge * rinv ;

  rinvsq = rinv * rinv ;

  CoulombicForceX = vcoul * rinvsq * differenceX ;
  CoulombicForceY = vcoul * rinvsq * differenceY ;
  CoulombicForceZ = vcoul * rinvsq * differenceZ ;
}

void CompleteMDFloat(float atomOneCurrentX, float atomOneCurrentY, 
		     float atomOneCurrentZ, float atomOneCurrentCharge,
		     float atomTwoCurrentX, float atomTwoCurrentY, 
		     float atomTwoCurrentZ, float atomTwoCurrentCharge,
		     float currentConstant12, float currentConstant6, 
		     float tableLookup,
		     float& VanDerWaalEnergy, float& CoulombicForceX, 
		     float& CoulombicForceY, float& CoulombicForceZ)
{
  float twelfthTerm ;
  float sixthTerm ;
  float radiusToTheTwelfth ;
  float radiusToTheSixth ;
  float radiusSquared ;
  float distanceXSquared ;
  float differenceX ;
  float distanceYSquared ;
  float differenceY ;
  float distanceZSquared ;
  float differenceZ ;

  // Call the Coulombic force module
  MDFloat(atomOneCurrentX, 
	  atomOneCurrentY, 
	  atomOneCurrentZ, 
	  atomOneCurrentCharge, 
	  atomTwoCurrentX, 
	  atomTwoCurrentY, 
	  atomTwoCurrentZ, 
	  atomTwoCurrentCharge, 
	  tableLookup, 
	  CoulombicForceX, 
	  CoulombicForceY, 
	  CoulombicForceZ);
  
  // Perform the calculations for the VanDerWaal Energy

  differenceX = atomOneCurrentX - atomTwoCurrentX ;
  differenceY = atomOneCurrentY - atomTwoCurrentY ;
  differenceZ = atomOneCurrentZ - atomTwoCurrentZ ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;
  
  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  radiusToTheSixth = radiusSquared * radiusSquared * radiusSquared ;
  radiusToTheTwelfth = radiusToTheSixth * radiusToTheSixth ;

  twelfthTerm = currentConstant12 * radiusToTheTwelfth ;
  sixthTerm = currentConstant6 * radiusToTheSixth ;

  VanDerWaalEnergy = twelfthTerm - sixthTerm ;
}

int main()
{
  float VDW ;
  float CX ;
  float CY ;
  float CZ ;

  CompleteMDFloat(1.5, 1.5, 1.5, 1.5, 2.5, 2.5, 2.5, -1.5, 
		  1.5, 1.5, 1.5, VDW, CX, CY, CZ) ;
  printf("--- Test case 1 ---\n") ;
  printf("atomOneCurrentX: %f\n", 1.5) ;
  printf("atomOneCurrentY: %f\n", 1.5) ;
  printf("atomOneCurrentZ: %f\n", 1.5) ;
  printf("atomOneCurrentCharge: %f\n", 1.5) ;
  printf("atomTwoCurrentX: %f\n", 2.5) ;
  printf("atomTwoCurrentY: %f\n", 2.5) ;
  printf("atomTwoCurrentZ: %f\n", 2.5) ;
  printf("atomTwoCurrentCharge: %f\n", -1.5) ;
  printf("currentConstant12: %f\n", 1.5) ;
  printf("currentConstant6: %f\n", 1.5) ;
  printf("tableLookup: %f\n", 1.5) ;
  printf("VanDerWaalEnergy: %f\n", VDW) ;
  printf("CoulombicForceX: %f\n", CX) ;
  printf("CoulombicForceY: %f\n", CY) ;
  printf("CoulombicForceZ: %f\n", CZ) ;
  printf("\n") ;

  CompleteMDFloat(1.5, 2.5, 3.5, -1.5, 3.5, 2.5, 1.5, 1.5, 
		  2.5, 2.5, 2.5, VDW, CX, CY, CZ) ;
  printf("--- Test case 2 ---\n") ;
  printf("atomOneCurrentX: %f\n", 1.5) ;
  printf("atomOneCurrentY: %f\n", 2.5) ;
  printf("atomOneCurrentZ: %f\n", 3.5) ;
  printf("atomOneCurrentCharge: %f\n", -1.5) ;
  printf("atomTwoCurrentX: %f\n", 3.5) ;
  printf("atomTwoCurrentY: %f\n", 2.5) ;
  printf("atomTwoCurrentZ: %f\n", 1.5) ;
  printf("atomTwoCurrentCharge: %f\n", 1.5) ;
  printf("currentConstant12: %f\n", 2.5) ;
  printf("currentConstant6: %f\n", 2.5) ;
  printf("tableLookup: %f\n", 2.5) ;
  printf("VanDerWaalEnergy: %f\n", VDW) ;
  printf("CoulombicForceX: %f\n", CX) ;
  printf("CoulombicForceY: %f\n", CY) ;
  printf("CoulombicForceZ: %f\n", CZ) ;
  printf("\n") ;

  CompleteMDFloat(1.5, 0.5, 1.5, 1.5, 2.5, 2.5, 2.5, 
		  2.5, -1.5, 1.5, 2.5, VDW, CX, CY, CZ) ;
  printf("--- Test case 3 ---\n") ;
  printf("atomOneCurrentX: %f\n", 1.5) ;
  printf("atomOneCurrentY: %f\n", 0.5) ;
  printf("atomOneCurrentZ: %f\n", 1.5) ;
  printf("atomOneCurrentCharge: %f\n", 1.5) ;
  printf("atomTwoCurrentX: %f\n", 2.5) ;
  printf("atomTwoCurrentY: %f\n", 2.5) ;
  printf("atomTwoCurrentZ: %f\n", 2.5) ;
  printf("atomTwoCurrentCharge: %f\n", 2.5) ;
  printf("currentConstant12: %f\n", -1.5) ;
  printf("currentConstant6: %f\n", 1.5) ;
  printf("tableLookup: %f\n", 2.5) ;
  printf("VanDerWaalEnergy: %f\n", VDW) ;
  printf("CoulombicForceX: %f\n", CX) ;
  printf("CoulombicForceY: %f\n", CY) ;
  printf("CoulombicForceZ: %f\n", CZ) ;
  printf("\n") ;

  return 0 ;
}
