#include <stdio.h>

void Pow10(int x_in, int& y_out)
{
  int total ;
  int i ;
  total = 1 ;
  for (i = 0 ; i < 10 ; ++i)
  {
    total *= x_in ;
  }
  y_out = total ;
}

int main()
{
  int result ;

  Pow10(1, result) ;
  printf("--- Test case 1 ---\n") ;
  printf("x_in: %d\n", 1) ;
  printf("y_out: %d\n", result) ;
  printf("\n") ;

  Pow10(-4, result) ;
  printf("--- Test case 2 ---\n") ;
  printf("x_in: %d\n", -4) ;
  printf("y_out: %d\n", result) ;
  printf("\n") ;

  Pow10(0, result) ;
  printf("--- Test case 3 ---\n") ;
  printf("x_in: %d\n", 0) ;
  printf("y_out: %d\n", result) ;
  printf("\n") ;

  return 0 ;
}
