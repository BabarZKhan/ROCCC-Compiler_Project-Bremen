#include <stdio.h>

typedef int ROCCC_int2 ;
typedef int ROCCC_int8 ;

void SingleCell(ROCCC_int8 S_in, ROCCC_int8 T_in, 
		ROCCC_int8 upper_in, ROCCC_int8 upperLeft_in,
		ROCCC_int8 left_in, ROCCC_int8& current_out)
{
  const int matchCost = 4 ;
  const int mismatchCost = 3 ;
  const int insertCost = 2 ;
  const int deleteCost = 1 ;

  ROCCC_int8 intermediate0 ;
  ROCCC_int8 intermediate1 ;

  if (S_in == T_in)
  {
    intermediate0 = upperLeft_in + matchCost ;
  }
  else
  {
    intermediate0 = upperLeft_in + mismatchCost ;
  }
 
  if (upper_in + insertCost > left_in + deleteCost)
  {
    intermediate1 = upper_in + insertCost ;
  }
  else
  {
    intermediate1 = left_in + deleteCost ;
  }
  if (intermediate0 > intermediate1) 
  {
    current_out = intermediate0 ;
  }
  else
  {
    current_out = intermediate1 ;
  }
}

int main()
{
  int result ;
  
  SingleCell(1, 1, 1, 1, 1, result) ;
  printf("--- Test case 1 ---\n") ;
  printf("S_in: %d\n", 1) ;
  printf("T_in: %d\n", 1) ;
  printf("upper_in: %d\n", 1) ;
  printf("upperLeft_in: %d\n", 1) ;
  printf("left_in: %d\n", 1) ;
  printf("current_out: %d\n", result) ;
  printf("\n") ;

  SingleCell(1, 2, 3, 4, 5, result) ;
  printf("--- Test case 2 ---\n") ;
  printf("S_in: %d\n", 1) ;
  printf("T_in: %d\n", 2) ;
  printf("upper_in: %d\n", 3) ;
  printf("upperLeft_in: %d\n", 4) ;
  printf("left_in: %d\n", 5) ;
  printf("current_out: %d\n", result) ;
  printf("\n") ;

  SingleCell(-1, 1, 4, 0, 2, result) ;
  printf("--- Test case 3 ---\n") ;
  printf("S_in: %d\n", -1) ;
  printf("T_in: %d\n", 1) ;
  printf("upper_in: %d\n", 4) ;
  printf("upperLeft_in: %d\n", 0) ;
  printf("left_in: %d\n", 2) ;
  printf("current_out: %d\n", result) ;
  printf("\n") ;

  return 0 ;
}
