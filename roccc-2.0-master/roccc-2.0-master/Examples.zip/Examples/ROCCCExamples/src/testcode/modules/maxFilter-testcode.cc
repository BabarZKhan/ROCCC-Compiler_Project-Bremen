#include <stdio.h>

void Max(int A0_in, int A1_in ,int A2_in, int& max_out)
{
  int tmp1 ;
  if (A0_in > A1_in)
  {
    tmp1 = A0_in ;
  }
  else
  {
    tmp1 = A1_in ;
  }
  if (tmp1 > A2_in)
  {
    max_out = tmp1 ;
  }
  else
  {
    max_out = A2_in ;
  }
}

int main()
{
  int result ;

  Max(1, 2, 3, result) ;
  printf("--- Test case 1 ---\n") ;
  printf("A0_in: %d\n", 1) ;
  printf("A1_in: %d\n", 2) ;
  printf("A2_in: %d\n", 3) ;
  printf("max_out: %d\n", result) ;
  printf("\n") ;

  Max(-1, -1, -1, result) ;
  printf("--- Test case 2 ---\n") ;
  printf("A0_in: %d\n", -1) ;
  printf("A1_in: %d\n", -1) ;
  printf("A2_in: %d\n", -1) ;
  printf("max_out: %d\n", result) ;
  printf("\n") ;

  Max(5, 4, 3, result) ;
  printf("--- Test case 3 ---\n") ;
  printf("A0_in: %d\n", 5) ;
  printf("A1_in: %d\n", 4) ;
  printf("A2_in: %d\n", 3) ;
  printf("max_out: %d\n", result) ;
  printf("\n") ;

  Max(0, 0, 0, result) ;
  printf("--- Test case 4 ---\n") ;
  printf("A0_in: %d\n", 0) ;
  printf("A1_in: %d\n", 0) ;
  printf("A2_in: %d\n", 0) ;
  printf("max_out: %d\n", result) ;
  printf("\n") ;

  Max(-1, 0, 1, result) ;
  printf("--- Test case 5 ---\n") ;
  printf("A0_in: %d\n", -1) ;
  printf("A1_in: %d\n", 0) ;
  printf("A2_in: %d\n", 1) ;
  printf("max_out: %d\n", result) ;
  printf("\n") ;

  return 0 ;
}
