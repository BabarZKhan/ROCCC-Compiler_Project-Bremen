#include <stdio.h>

void MAX(int A0_in, int A1_in, int A2_in, int& max_out)
{
  int tmp1 ;
  if (A0_in > A1_in)
  {
    tmp1 = A0_in ;
  }
  else
  {
    tmp1 = A1_in ;
  }
  if (tmp1 > A2_in)
  {
    max_out = tmp1 ;
  }
  else
  {
    max_out = A2_in ;
  }
}

void ComplexIfModule(int x_in, int y_in, int z_in, int& final_out)
{
  int temp ;
  int temp2 ;

  // These initializations added to compensate for all the paths that 
  //  don't necessarily initialize all values
  temp = 0 ;
  temp2 = 0 ;
  
  if (x_in != y_in)
  {
    temp = z_in ;
    temp = temp + 5 ;
  }
  else
  {
    if (z_in == 15)
    {
      MAX(x_in, y_in, z_in, temp2) ;
    }
    else
    {
      MAX(y_in, z_in, x_in, temp2) ;
    }
  }
  final_out = temp + temp2 ;
}

int main()
{
  int result ;

  ComplexIfModule(1, 1, 1, result) ;
  printf("--- Test case 1 ---\n") ;
  printf("x_in: %d\n", 1) ;
  printf("y_in: %d\n", 1) ;
  printf("z_in: %d\n", 1) ;
  printf("final_out: %d\n", result) ;
  printf("\n") ;

  ComplexIfModule(1, 2, 3, result) ;
  printf("--- Test case 2 ---\n") ;
  printf("x_in: %d\n", 1) ;
  printf("y_in: %d\n", 2) ;
  printf("z_in: %d\n", 3) ;
  printf("final_out: %d\n", result) ;
  printf("\n") ;

  ComplexIfModule(2, 2, 10, result) ;
  printf("--- Test case 3 ---\n") ;
  printf("x_in: %d\n", 2) ;
  printf("y_in: %d\n", 2) ;
  printf("z_in: %d\n", 10) ;
  printf("final_out: %d\n", result) ;
  printf("\n") ;

  return 0 ;
}
