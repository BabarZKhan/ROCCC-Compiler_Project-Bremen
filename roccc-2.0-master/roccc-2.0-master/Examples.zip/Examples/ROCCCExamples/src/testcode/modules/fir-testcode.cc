#include <stdio.h>

void FIR(int A0_in, int A1_in, int A2_in, int A3_in, int A4_in, 
	 int& result_out)
{
  const int T[5] = {3, 5, 7, 9, 11 } ;
  result_out = A0_in * T[0] +
    A1_in * T[1] +
    A2_in * T[2] +
    A3_in * T[3] +
    A4_in * T[4] ;
}

int main()
{
  int result ;
  
  FIR(1, 2, 3, 4, 5, result) ;
  printf("--- Test case 1 ---\n") ;
  printf("A0: %d\n", 1) ;
  printf("A1: %d\n", 2) ;
  printf("A2: %d\n", 3) ;
  printf("A3: %d\n", 4) ;
  printf("A4: %d\n", 5) ;
  printf("result_out: %d\n", result) ;
  printf("\n") ;

  FIR(5, 4, 3, 2, 1, result) ;
  printf("--- Test case 2 ---\n") ;
  printf("A0: %d\n", 5) ;
  printf("A1: %d\n", 4) ;
  printf("A2: %d\n", 3) ;
  printf("A3: %d\n", 2) ;
  printf("A4: %d\n", 1) ;
  printf("result_out: %d\n", result) ;
  printf("\n") ;

  FIR(-1, 1, -1, 1, -1, result) ;
  printf("--- Test case 3 ---\n") ;
  printf("A0: %d\n", -1) ;
  printf("A1: %d\n", 1) ;
  printf("A2: %d\n", -1) ;
  printf("A3: %d\n", 1) ;
  printf("A4: %d\n", -1) ;
  printf("result_out: %d\n", result) ;
  printf("\n") ;

  return 0 ;
}
