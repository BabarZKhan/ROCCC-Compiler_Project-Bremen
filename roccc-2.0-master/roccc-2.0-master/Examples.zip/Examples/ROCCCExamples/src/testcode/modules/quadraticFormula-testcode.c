#include <stdio.h>
#include <math.h>

typedef float ROCCC_float32 ;
typedef int ROCCC_int1 ;

void QuadraticFormula(ROCCC_float32 a_in, 
		      ROCCC_float32 b_in,
		      ROCCC_float32 c_in,
		      ROCCC_float32& x1Real_out,
		      ROCCC_float32& x1Imag_out,
		      ROCCC_float32& x2Real_out,
		      ROCCC_float32& x2Imag_out,
		      ROCCC_int1& infinity_out
		      ) 
{
  ROCCC_float32 sqrtValue ;
  ROCCC_float32 bSquaredMinusFourAC ;
  ROCCC_float32 twoA ;

  ROCCC_float32 tempReal1 ;
  ROCCC_float32 tempImag1 ;
  ROCCC_float32 tempReal2 ;
  ROCCC_float32 tempImag2 ;

  ROCCC_int1 tempInfinity ;

  // If A is zero, it is not quadratic, thus you get division by zero
  if (a_in == 0)
  {
    tempReal1 = 0 ;
    tempImag1 = 0 ;
    tempReal2 = 0 ;
    tempImag2 = 0 ;
    tempInfinity = 1 ;
  }
  else
  {
    bSquaredMinusFourAC = b_in * b_in - 4 * a_in * c_in ;
    twoA = 2 * a_in ;
    // If the inside of the square root is negative, then you get
    //  imaginary numbers
    if (bSquaredMinusFourAC >= 0)
    {
      sqrtValue = sqrt(bSquaredMinusFourAC) ; // Call the software square root
      tempReal1 = -b_in + sqrtValue / twoA ;
      tempReal2 = -b_in - sqrtValue / twoA ;
      tempImag1 = 0 ;
      tempImag2 = 0 ;
    }
    else
    {
      tempReal1 = -b_in/twoA ;
      tempReal2 = tempReal1 ;
      sqrtValue = sqrt(-bSquaredMinusFourAC) ; // Call the sofware square root
      tempImag1 = sqrtValue / twoA ;
      tempImag2 = -tempImag1 ;
    }
    tempInfinity = 0 ;
  }
  
  x1Real_out = tempReal1 ;
  x1Imag_out = tempImag1 ;
  x2Real_out = tempReal2 ;
  x2Imag_out = tempImag2 ;
  
  infinity_out = tempInfinity ;
}

int main()
{
  float x1Real ;
  float x1Imag ;
  float x2Real ;
  float x2Imag ;
  ROCCC_int1 infinity ;

  QuadraticFormula(1.0, 1.0, 1.0, 
		   x1Real, x1Imag, x2Real, x2Imag, infinity) ;
  printf("--- Test case 1 ---\n") ;
  printf("a_in: %f\n", 1.0) ;
  printf("b_in: %f\n", 1.0) ;
  printf("c_in: %f\n", 1.0) ;
  printf("x1Real_out: %f\n", x1Real) ;
  printf("x1Imag_out: %f\n", x1Imag) ;
  printf("x2Real_out: %f\n", x2Real) ;
  printf("x2Imag_out: %f\n", x2Imag) ;
  printf("infinity_out: %d\n", infinity) ;
  printf("\n") ;

  QuadraticFormula(-1.0, -1.0, -1.0, 
		   x1Real, x1Imag, x2Real, x2Imag, infinity) ;
  printf("--- Test case 2 ---\n") ;
  printf("a_in: %f\n", -1.0) ;
  printf("b_in: %f\n", -1.0) ;
  printf("c_in: %f\n", -1.0) ;
  printf("x1Real_out: %f\n", x1Real) ;
  printf("x1Imag_out: %f\n", x1Imag) ;
  printf("x2Real_out: %f\n", x2Real) ;
  printf("x2Imag_out: %f\n", x2Imag) ;
  printf("infinity_out: %d\n", infinity) ;
  printf("\n") ;

  QuadraticFormula(2.0, 3.0, 4.0, 
		   x1Real, x1Imag, x2Real, x2Imag, infinity) ;
  printf("--- Test case 3 ---\n") ;
  printf("a_in: %f\n", 2.0) ;
  printf("b_in: %f\n", 3.0) ;
  printf("c_in: %f\n", 4.0) ;
  printf("x1Real_out: %f\n", x1Real) ;
  printf("x1Imag_out: %f\n", x1Imag) ;
  printf("x2Real_out: %f\n", x2Real) ;
  printf("x2Imag_out: %f\n", x2Imag) ;
  printf("infinity_out: %d\n", infinity) ;
  printf("\n") ;

  QuadraticFormula(0.0, 5.5, -10.0, 
		   x1Real, x1Imag, x2Real, x2Imag, infinity) ;
  printf("--- Test case 4 ---\n") ;
  printf("a_in: %f\n", 0.0) ;
  printf("b_in: %f\n", 5.5) ;
  printf("c_in: %f\n", -10.0) ;
  printf("x1Real_out: %f\n", x1Real) ;
  printf("x1Imag_out: %f\n", x1Imag) ;
  printf("x2Real_out: %f\n", x2Real) ;
  printf("x2Imag_out: %f\n", x2Imag) ;
  printf("infinity_out: %d\n", infinity) ;
  printf("\n") ;

  return 0 ;
}
