#include <stdio.h>

void FFT(int realOne, int imagOne, int realTwo, int imagTwo,
	 int realOmega, int imagOmega, 
	 int& A0_out, int& A1_out, int& A2_out, int& A3_out)
{
  A0_out = realOne + (realOmega * realTwo) - (imagOmega * imagTwo) ;
  A1_out = imagOne + (realOmega * imagTwo) + (imagOmega * realTwo) ;
  A2_out = realOne - (realOmega * realTwo) + (imagOmega * imagTwo) ;
  A3_out = imagOne - (realOmega * imagTwo) - (imagOmega * realTwo) ;
}

void FFTOneStage(int real0, int imag0, 
		 int real1, int imag1,
		 int real2, int imag2,
		 int real3, int imag3,
		 int real4, int imag4,
		 int real5, int imag5,
		 int real6, int imag6,
		 int real7, int imag7,
		 int realOmega, int imagOmega,
		 int& x0Real, int& x0Imag,
		 int& x1Real, int& x1Imag,
		 int& x2Real, int& x2Imag,
		 int& x3Real, int& x3Imag,
		 int& x4Real, int& x4Imag,
		 int& x5Real, int& x5Imag,
		 int& x6Real, int& x6Imag,
		 int& x7Real, int& x7Imag)
{
  FFT(real0, 
      imag0, 
      real1, 
      imag1, 
      realOmega, 
      imagOmega, 
      x0Real, 
      x0Imag, 
      x1Real, 
      x1Imag);

  FFT(real2, 
      imag2, 
      real3, 
      imag3, 
      realOmega, 
      imagOmega, 
      x2Real, 
      x2Imag, 
      x3Real, 
      x3Imag);

  FFT(real4, 
      imag4, 
      real5, 
      imag5, 
      realOmega, 
      imagOmega, 
      x4Real, 
      x4Imag, 
      x5Real, 
      x5Imag);
  
  FFT(real6, 
      imag6, 
      real7, 
      imag7, 
      realOmega, 
      imagOmega, 
      x6Real, 
      x6Imag, 
      x7Real, 
      x7Imag);
}

int main()
{
  int x0Real ;
  int x0Imag ;
  int x1Real ;
  int x1Imag ;
  int x2Real ;
  int x2Imag ;
  int x3Real ;
  int x3Imag ;
  int x4Real ;
  int x4Imag ;
  int x5Real ;
  int x5Imag ;
  int x6Real ;
  int x6Imag ;
  int x7Real ;
  int x7Imag ;

  FFTOneStage(1, 1,
	      2, 2,
	      3, 3,
	      4, 4,
	      5, 5,
	      6, 6,
	      7, 7,
	      8, 8,
	      1, 1, 
	      x0Real, x0Imag,
	      x1Real, x1Imag,
	      x2Real, x2Imag,
	      x3Real, x3Imag,
	      x4Real, x4Imag,
	      x5Real, x5Imag,
	      x6Real, x6Imag,
	      x7Real, x7Imag) ;
  printf("--- Test case 1 ---\n") ;
  printf("real0: %d\n", 1) ;
  printf("imag0: %d\n", 1) ;
  printf("real1: %d\n", 2) ;
  printf("imag1: %d\n", 2) ;
  printf("real2: %d\n", 3) ;
  printf("imag2: %d\n", 3) ;
  printf("real3: %d\n", 4) ;
  printf("imag3: %d\n", 4) ;
  printf("real4: %d\n", 5) ;
  printf("imag4: %d\n", 5) ;
  printf("real5: %d\n", 6) ;
  printf("imag5: %d\n", 6) ;
  printf("real6: %d\n", 7) ;
  printf("imag6: %d\n", 7) ;
  printf("real7: %d\n", 8) ;
  printf("imag7: %d\n", 8) ;
  printf("realOmega: %d\n", 1) ;
  printf("imagOmega: %d\n", 1) ;
  printf("x0Real: %d\n", x0Real) ;
  printf("x0Imag: %d\n", x0Imag) ;
  printf("x1Real: %d\n", x1Real) ;
  printf("x1Imag: %d\n", x1Imag) ;
  printf("x2Real: %d\n", x2Real) ;
  printf("x2Imag: %d\n", x2Imag) ;
  printf("x3Real: %d\n", x3Real) ;
  printf("x3Imag: %d\n", x3Imag) ;
  printf("x4Real: %d\n", x4Real) ;
  printf("x4Imag: %d\n", x4Imag) ;
  printf("x5Real: %d\n", x5Real) ;
  printf("x5Imag: %d\n", x5Imag) ;
  printf("x6Real: %d\n", x6Real) ;
  printf("x6Imag: %d\n", x6Imag) ;
  printf("x7Real: %d\n", x7Real) ;
  printf("x7Imag: %d\n", x7Imag) ;
  printf("\n") ;

  return 0 ;
}
