#include <stdio.h>

void LoopTest(int x_in, int& y_out)
{
  int i ;
  int currentSum ;
  int A[10] ;

  currentSum = 0 ;
  for (i = 0 ; i < 10 ; ++i)
  {
    A[i] = i ;
  }
  
  for (i = 0 ; i < 10  ; ++i)
  {
    if (x_in == A[i])
    {
      currentSum = currentSum + A[i] ;
    }
    else
    {
      currentSum = currentSum + 1 ;
    }
  }
  y_out = currentSum + x_in ;
}

int main()
{
  int result ;

  LoopTest(0, result) ;
  printf("--- Test case 1 ---\n") ;
  printf("x_in: %d\n", 0) ;
  printf("y_out: %d\n", result) ;
  printf("\n") ;

  LoopTest(5, result) ;
  printf("--- Test case 2 ---\n") ;
  printf("x_in: %d\n", 5) ;
  printf("y_out: %d\n", result) ;
  printf("\n") ;

  LoopTest(11, result) ;
  printf("--- Test case 3 ---\n") ;
  printf("x_in: %d\n", 11) ;
  printf("y_out: %d\n", result) ;
  printf("\n") ;

  LoopTest(-1, result) ;
  printf("--- Test case 4 ---\n") ;
  printf("x_in: %d\n", -1) ;
  printf("y_out: %d\n", result) ;
  printf("\n") ;

  return 0 ;
}
