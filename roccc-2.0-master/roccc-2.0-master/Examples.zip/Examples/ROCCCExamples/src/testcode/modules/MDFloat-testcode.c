#include <stdio.h>

void MDFloat(float atomOneCurrentX, float atomOneCurrentY, float atomOneCurrentZ,
	   float atomOneCurrentCharge,
	   float atomTwoCurrentX, float atomTwoCurrentY, float atomTwoCurrentZ,
	   float atomTwoCurrentCharge,
	   float tableLookup,
	   float& CoulombicForceX, float& CoulombicForceY, float& CoulombicForceZ)
{
  float radiusSquared ;
  float distanceXSquared ;
  float distanceYSquared ;
  float distanceZSquared ;
  float differenceX ;
  float differenceY ;
  float differenceZ ;
  float vcoul ;
  float rinvsq ;
  float rinv ;

  differenceX = atomOneCurrentX - atomTwoCurrentX ;
  differenceY = atomOneCurrentY - atomTwoCurrentY ;
  differenceZ = atomOneCurrentZ - atomTwoCurrentZ ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;

  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  
  rinv = (tableLookup * (((radiusSquared * tableLookup) * tableLookup))) ;

  vcoul = atomOneCurrentCharge * atomTwoCurrentCharge * rinv ;

  rinvsq = rinv * rinv ;

  CoulombicForceX = vcoul * rinvsq * differenceX ;
  CoulombicForceY = vcoul * rinvsq * differenceY ;
  CoulombicForceZ = vcoul * rinvsq * differenceZ ;
}

int main()
{
  float CX ;
  float CY ;
  float CZ ;

  MDFloat(1.5, 1.5, 1.5, 1.5,
	  2.5, 2.5, 2.5, -1.5,
	  1.5,
	  CX, CY, CZ) ;
  printf("--- Test case 1 ---\n") ;
  printf("atomOneCurrentX: %f\n", 1.5) ;
  printf("atomOneCurrentY: %f\n", 1.5) ;
  printf("atomOneCurrentZ: %f\n", 1.5) ;
  printf("atomOneCurrentCharge: %f\n", 1.5) ;
  printf("atomTwoCurrentX: %f\n", 2.5) ;
  printf("atomTwoCurrentY: %f\n", 2.5) ;
  printf("atomTwoCurrentZ: %f\n", 2.5) ;
  printf("atomTwoCurrentCharge: %f\n", -1.5) ;
  printf("tableLookup: %f\n", 1.5) ;
  printf("CoulombicForceX: %f\n", CX) ;
  printf("CoulombicForceY: %f\n", CY) ;
  printf("CoulombicForceZ: %f\n", CZ) ;
  printf("\n") ;

  MDFloat(1.2, 2.2, 3.2, -1.2,
	3.2, 2.2, 1.2, 1.2,
	2.2,
	CX, CY, CZ) ;
  printf("--- Test case 2 ---\n") ;
  printf("atomOneCurrentX: %f\n", 1.2) ;
  printf("atomOneCurrentY: %f\n", 2.2) ;
  printf("atomOneCurrentZ: %f\n", 3.2) ;
  printf("atomOneCurrentCharge: %f\n", -1.2) ;
  printf("atomTwoCurrentX: %f\n", 3.2) ;
  printf("atomTwoCurrentY: %f\n", 2.2) ;
  printf("atomTwoCurrentZ: %f\n", 1.2) ;
  printf("atomTwoCurrentCharge: %f\n", 1.2) ;
  printf("tableLookup: %f\n", 2.2) ;
  printf("CoulombicForceX: %f\n", CX) ;
  printf("CoulombicForceY: %f\n", CY) ;
  printf("CoulombicForceZ: %f\n", CZ) ;
  printf("\n") ;

  MDFloat(0.4, 0.4, 0.4, 1.4,
	-1.4, 1.4, 0.4, 1.4,
	-1.4,
	CX, CY, CZ) ;
  printf("--- Test case 3 ---\n") ;
  printf("atomOneCurrentX: %f\n", 0.4) ;
  printf("atomOneCurrentY: %f\n", 0.4) ;
  printf("atomOneCurrentZ: %f\n", 0.4) ;
  printf("atomOneCurrentCharge: %f\n", 1.4) ;
  printf("atomTwoCurrentX: %f\n", -1.4) ;
  printf("atomTwoCurrentY: %f\n", 1.4) ;
  printf("atomTwoCurrentZ: %f\n", 0.4) ;
  printf("atomTwoCurrentCharge: %f\n", 1.4) ;
  printf("tableLookup: %f\n", -1.4) ;
  printf("CoulombicForceX: %f\n", CX) ;
  printf("CoulombicForceY: %f\n", CY) ;
  printf("CoulombicForceZ: %f\n", CZ) ;
  printf("\n") ;

  return 0 ;
}
