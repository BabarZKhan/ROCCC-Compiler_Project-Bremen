#include <stdio.h>

void MD(int atomOneCurrentX, int atomOneCurrentY, int atomOneCurrentZ,
	int atomOneCurrentCharge,
	int atomTwoCurrentX, int atomTwoCurrentY, int atomTwoCurrentZ,
	int atomTwoCurrentCharge,
	int tableLookup,
	int& CoulombicForceX, int& CoulombicForceY, int& CoulombicForceZ)
{
  int radiusSquared ;
  int distanceXSquared ;
  int distanceYSquared ;
  int distanceZSquared ;
  int differenceX ;
  int differenceY ;
  int differenceZ ;
  int vcoul ;
  int rinvsq ;
  int rinv ;

  differenceX = atomOneCurrentX - atomTwoCurrentX ;
  differenceY = atomOneCurrentY - atomTwoCurrentY ;
  differenceZ = atomOneCurrentZ - atomTwoCurrentZ ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;

  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  
  rinv = (tableLookup * (((radiusSquared * tableLookup) * tableLookup))) ;

  vcoul = atomOneCurrentCharge * atomTwoCurrentCharge * rinv ;

  rinvsq = rinv * rinv ;

  CoulombicForceX = vcoul * rinvsq * differenceX ;
  CoulombicForceY = vcoul * rinvsq * differenceY ;
  CoulombicForceZ = vcoul * rinvsq * differenceZ ;
}

int main()
{
  int CX ;
  int CY ;
  int CZ ;

  MD(1, 1, 1, 1,
     2, 2, 2, -1,
     1,
     CX, CY, CZ) ;
  printf("--- Test case 1 ---\n") ;
  printf("atomOneCurrentX: %d\n", 1) ;
  printf("atomOneCurrentY: %d\n", 1) ;
  printf("atomOneCurrentZ: %d\n", 1) ;
  printf("atomOneCurrentCharge: %d\n", 1) ;
  printf("atomTwoCurrentX: %d\n", 2) ;
  printf("atomTwoCurrentY: %d\n", 2) ;
  printf("atomTwoCurrentZ: %d\n", 2) ;
  printf("atomTwoCurrentCharge: %d\n", -1) ;
  printf("tableLookup: %d\n", 1) ;
  printf("CoulombicForceX: %d\n", CX) ;
  printf("CoulombicForceY: %d\n", CY) ;
  printf("CoulombicForceZ: %d\n", CZ) ;
  printf("\n") ;

  MD(1, 2, 3, -1,
     3, 2, 1, 1,
     2,
     CX, CY, CZ) ;
  printf("--- Test case 2 ---\n") ;
  printf("atomOneCurrentX: %d\n", 1) ;
  printf("atomOneCurrentY: %d\n", 2) ;
  printf("atomOneCurrentZ: %d\n", 3) ;
  printf("atomOneCurrentCharge: %d\n", -1) ;
  printf("atomTwoCurrentX: %d\n", 3) ;
  printf("atomTwoCurrentY: %d\n", 2) ;
  printf("atomTwoCurrentZ: %d\n", 1) ;
  printf("atomTwoCurrentCharge: %d\n", 1) ;
  printf("tableLookup: %d\n", 2) ;
  printf("CoulombicForceX: %d\n", CX) ;
  printf("CoulombicForceY: %d\n", CY) ;
  printf("CoulombicForceZ: %d\n", CZ) ;
  printf("\n") ;

  MD(0, 0, 0, 1,
     -1, 1, 0, 1,
     -1,
     CX, CY, CZ) ;
  printf("--- Test case 3 ---\n") ;
  printf("atomOneCurrentX: %d\n", 0) ;
  printf("atomOneCurrentY: %d\n", 0) ;
  printf("atomOneCurrentZ: %d\n", 0) ;
  printf("atomOneCurrentCharge: %d\n", 1) ;
  printf("atomTwoCurrentX: %d\n", -1) ;
  printf("atomTwoCurrentY: %d\n", 1) ;
  printf("atomTwoCurrentZ: %d\n", 0) ;
  printf("atomTwoCurrentCharge: %d\n", 1) ;
  printf("tableLookup: %d\n", -1) ;
  printf("CoulombicForceX: %d\n", CX) ;
  printf("CoulombicForceY: %d\n", CY) ;
  printf("CoulombicForceZ: %d\n", CZ) ;
  printf("\n") ;

  return 0 ;
}
