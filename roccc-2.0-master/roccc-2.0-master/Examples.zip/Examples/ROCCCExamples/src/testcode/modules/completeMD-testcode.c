#include <stdio.h>

void MD(int atomOneCurrentX, int atomOneCurrentY, int atomOneCurrentZ,
	int atomOneCurrentCharge,
	int atomTwoCurrentX, int atomTwoCurrentY, int atomTwoCurrentZ,
	int atomTwoCurrentCharge,
	int tableLookup,
	int& CoulombicForceX, int& CoulombicForceY, int& CoulombicForceZ)
{
  int radiusSquared ;
  int distanceXSquared ;
  int distanceYSquared ;
  int distanceZSquared ;
  int differenceX ;
  int differenceY ;
  int differenceZ ;
  int vcoul ;
  int rinvsq ;
  int rinv ;

  differenceX = atomOneCurrentX - atomTwoCurrentX ;
  differenceY = atomOneCurrentY - atomTwoCurrentY ;
  differenceZ = atomOneCurrentZ - atomTwoCurrentZ ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;

  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  
  rinv = (tableLookup * (((radiusSquared * tableLookup) * tableLookup))) ;

  vcoul = atomOneCurrentCharge * atomTwoCurrentCharge * rinv ;

  rinvsq = rinv * rinv ;

  CoulombicForceX = vcoul * rinvsq * differenceX ;
  CoulombicForceY = vcoul * rinvsq * differenceY ;
  CoulombicForceZ = vcoul * rinvsq * differenceZ ;
}

void CompleteMD(int atomOneCurrentX, int atomOneCurrentY, int atomOneCurrentZ,
		int atomOneCurrentCharge,
		int atomTwoCurrentX, int atomTwoCurrentY, int atomTwoCurrentZ,
		int atomTwoCurrentCharge,
		int currentConstant12, int currentConstant6, int tableLookup,
		int& VanDerWaalEnergy, int& CoulombicForceX, 
		int& CoulombicForceY, int& CoulombicForceZ)
{
  int twelfthTerm ;
  int sixthTerm ;
  int radiusToTheTwelfth ;
  int radiusToTheSixth ;
  int radiusSquared ;
  int distanceXSquared ;
  int differenceX ;
  int distanceYSquared ;
  int differenceY ;
  int distanceZSquared ;
  int differenceZ ;

  // Call the Coulombic force module
  MD(atomOneCurrentX, 
     atomOneCurrentY, 
     atomOneCurrentZ, 
     atomOneCurrentCharge, 
     atomTwoCurrentX, 
     atomTwoCurrentY, 
     atomTwoCurrentZ, 
     atomTwoCurrentCharge, 
     tableLookup, 
     CoulombicForceX, 
     CoulombicForceY, 
     CoulombicForceZ);
  
  // Perform the calculations for the VanDerWaal Energy

  differenceX = atomOneCurrentX - atomTwoCurrentX ;
  differenceY = atomOneCurrentY - atomTwoCurrentY ;
  differenceZ = atomOneCurrentZ - atomTwoCurrentZ ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;
  
  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  radiusToTheSixth = radiusSquared * radiusSquared * radiusSquared ;
  radiusToTheTwelfth = radiusToTheSixth * radiusToTheSixth ;

  twelfthTerm = currentConstant12 * radiusToTheTwelfth ;
  sixthTerm = currentConstant6 * radiusToTheSixth ;

  VanDerWaalEnergy = twelfthTerm - sixthTerm ;
}

int main()
{
  int VDW ;
  int CX ;
  int CY ;
  int CZ ;

  CompleteMD(1, 1, 1, 1, 2, 2, 2, -1, 1, 1, 1, VDW, CX, CY, CZ) ;
  printf("--- Test case 1 ---\n") ;
  printf("atomOneCurrentX: %d\n", 1) ;
  printf("atomOneCurrentY: %d\n", 1) ;
  printf("atomOneCurrentZ: %d\n", 1) ;
  printf("atomOneCurrentCharge: %d\n", 1) ;
  printf("atomTwoCurrentX: %d\n", 2) ;
  printf("atomTwoCurrentY: %d\n", 2) ;
  printf("atomTwoCurrentZ: %d\n", 2) ;
  printf("atomTwoCurrentCharge: %d\n", -1) ;
  printf("currentConstant12: %d\n", 1) ;
  printf("currentConstant6: %d\n", 1) ;
  printf("tableLookup: %d\n", 1) ;
  printf("VanDerWaalEnergy: %d\n", VDW) ;
  printf("CoulombicForceX: %d\n", CX) ;
  printf("CoulombicForceY: %d\n", CY) ;
  printf("CoulombicForceZ: %d\n", CZ) ;
  printf("\n") ;

  CompleteMD(1, 2, 3, -1, 3, 2, 1, 1, 2, 2, 2, VDW, CX, CY, CZ) ;
  printf("--- Test case 2 ---\n") ;
  printf("atomOneCurrentX: %d\n", 1) ;
  printf("atomOneCurrentY: %d\n", 2) ;
  printf("atomOneCurrentZ: %d\n", 3) ;
  printf("atomOneCurrentCharge: %d\n", -1) ;
  printf("atomTwoCurrentX: %d\n", 3) ;
  printf("atomTwoCurrentY: %d\n", 2) ;
  printf("atomTwoCurrentZ: %d\n", 1) ;
  printf("atomTwoCurrentCharge: %d\n", 1) ;
  printf("currentConstant12: %d\n", 2) ;
  printf("currentConstant6: %d\n", 2) ;
  printf("tableLookup: %d\n", 2) ;
  printf("VanDerWaalEnergy: %d\n", VDW) ;
  printf("CoulombicForceX: %d\n", CX) ;
  printf("CoulombicForceY: %d\n", CY) ;
  printf("CoulombicForceZ: %d\n", CZ) ;
  printf("\n") ;

  CompleteMD(1, 0, 1, 1, 2, 2, 2, 2, -1, 1, 2, VDW, CX, CY, CZ) ;
  printf("--- Test case 3 ---\n") ;
  printf("atomOneCurrentX: %d\n", 1) ;
  printf("atomOneCurrentY: %d\n", 0) ;
  printf("atomOneCurrentZ: %d\n", 1) ;
  printf("atomOneCurrentCharge: %d\n", 1) ;
  printf("atomTwoCurrentX: %d\n", 2) ;
  printf("atomTwoCurrentY: %d\n", 2) ;
  printf("atomTwoCurrentZ: %d\n", 2) ;
  printf("atomTwoCurrentCharge: %d\n", 2) ;
  printf("currentConstant12: %d\n", -1) ;
  printf("currentConstant6: %d\n", 1) ;
  printf("tableLookup: %d\n", 2) ;
  printf("VanDerWaalEnergy: %d\n", VDW) ;
  printf("CoulombicForceX: %d\n", CX) ;
  printf("CoulombicForceY: %d\n", CY) ;
  printf("CoulombicForceZ: %d\n", CZ) ;
  printf("\n") ;

  return 0 ;
}
