#include <stdio.h>

void MAC(int num1_in, int num2_in, int num3_in, int& sum_out)
{
  sum_out = (num1_in * num2_in) + num3_in ;
}

int main()
{
  int result ;

  MAC(1, 2, 3, result) ;
  printf("--- Test case 1 ---\n") ;
  printf("num1_in: %d\n", 1) ;
  printf("num2_in: %d\n", 2) ;
  printf("num3_in: %d\n", 3) ;
  printf("sum_out: %d\n", result) ;
  printf("\n") ;

  MAC(5, 4, 3, result) ;
  printf("--- Test case 2 ---\n") ;
  printf("num1_in: %d\n", 5) ;
  printf("num2_in: %d\n", 4) ;
  printf("num3_in: %d\n", 3) ;
  printf("sum_out: %d\n", result) ;
  printf("\n") ;

  MAC(-1, -1, -1, result) ;
  printf("--- Test case 3 ---\n") ;
  printf("num1_in: %d\n", -1) ;
  printf("num2_in: %d\n", -1) ;
  printf("num3_in: %d\n", -1) ;
  printf("sum_out: %d\n", result) ;
  printf("\n") ;

  MAC(-1, 0, 1, result) ;
  printf("--- Test case 4 ---\n") ;
  printf("num1_in: %d\n", -1) ;
  printf("num2_in: %d\n", 0) ;
  printf("num3_in: %d\n", 1) ;
  printf("sum_out: %d\n", result) ;
  printf("\n") ;

  return 0 ;
}
