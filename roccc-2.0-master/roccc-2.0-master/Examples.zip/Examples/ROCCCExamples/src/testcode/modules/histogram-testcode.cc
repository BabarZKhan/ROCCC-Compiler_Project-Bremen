#include <stdio.h>

void Histogram(int count_in, int value_in, int input_in, int valid_in,
	       int& count_out, int& value_out, int& stream_out, 
	       int& valid_out)
{
  int tmp1 ;
  tmp1 = ((count_in == 0) & (valid_in == 1)) ;
  if (tmp1)
  {
    value_out = input_in ;
  }
  else
  {
    value_out = value_in ;
  }
  if (tmp1 | ((valid_in == 1) & (value_out == input_in)))
  {
    count_out = count_in + 1 ;
    valid_out = 0 ;
    stream_out = 0 ;
  }
  else
  {
    count_out = count_in ;
    valid_out = valid_in ;
    stream_out = input_in ;
  }

}

int main()
{
  int count ;
  int value ;
  int stream ;
  int valid ;

  Histogram(0, 0, 5, 1, count, value, stream, valid) ;
  printf("--- Test case 1 ---\n") ;
  printf("count_in: %d\n", 0) ;
  printf("value_in: %d\n", 0) ;
  printf("input_in: %d\n", 5) ;
  printf("valid_in: %d\n", 1) ;
  printf("count_out: %d\n", count) ;
  printf("value_out: %d\n", value) ;
  printf("stream_out: %d\n", stream) ;
  printf("valid_out: %d\n", valid) ;
  printf("\n") ;

  Histogram(3, 2, 5, 1, count, value, stream, valid) ;
  printf("--- Test case 2 ---\n") ;
  printf("count_in: %d\n", 3) ;
  printf("value_in: %d\n", 2) ;
  printf("input_in: %d\n", 5) ;
  printf("valid_in: %d\n", 1) ;
  printf("count_out: %d\n", count) ;
  printf("value_out: %d\n", value) ;
  printf("stream_out: %d\n", stream) ;
  printf("valid_out: %d\n", valid) ;
  printf("\n") ;

  Histogram(3, 2, 2, 1, count, value, stream, valid) ;
  printf("--- Test case 3 ---\n") ;
  printf("count_in: %d\n", 3) ;
  printf("value_in: %d\n", 2) ;
  printf("input_in: %d\n", 2) ;
  printf("valid_in: %d\n", 1) ;
  printf("count_out: %d\n", count) ;
  printf("value_out: %d\n", value) ;
  printf("stream_out: %d\n", stream) ;
  printf("valid_out: %d\n", valid) ;
  printf("\n") ;

  Histogram(2, 2, 2, 0, count, value, stream, valid) ;
  printf("--- Test case 4 ---\n") ;
  printf("count_in: %d\n", 2) ;
  printf("value_in: %d\n", 2) ;
  printf("input_in: %d\n", 2) ;
  printf("valid_in: %d\n", 0) ;
  printf("count_out: %d\n", count) ;
  printf("value_out: %d\n", value) ;
  printf("stream_out: %d\n", stream) ;
  printf("valid_out: %d\n", valid) ;
  printf("\n") ;

  return 0 ;
}
