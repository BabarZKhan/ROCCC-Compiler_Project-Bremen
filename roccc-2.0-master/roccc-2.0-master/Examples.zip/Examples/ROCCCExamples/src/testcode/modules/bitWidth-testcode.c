/*

  In order to emulate the different bit widths we support, the C level
    code must strip away some of the result bits.

*/

#include <stdio.h>

// To declare a variable of a different bit size, you must define a typedef
//  of the form ROCCC_intX, where X is the size in bits you wish it to be.
//  This only works with ints, not floating point values.

typedef int ROCCC_int23 ;
typedef int ROCCC_int14 ;
typedef int ROCCC_int31 ;
typedef int ROCCC_int7 ;
typedef int ROCCC_int5 ;

void BitWidth(ROCCC_int23 A_in, ROCCC_int14 B_in,
	      ROCCC_int31 C_in, ROCCC_int7 D_in,
	      ROCCC_int5& Final_out)
{
  Final_out = (A_in * B_in) - (C_in / D_in) + 10 ;
}

void BitWidthEmulation(ROCCC_int23 A_in, ROCCC_int14 B_in,
		       ROCCC_int31 C_in, ROCCC_int7 D_in,
		       ROCCC_int5& Final_out)
{

  long int tmpA = A_in & 0x007fffff ;
  long int tmpB = B_in & 0x00003fff ;

  // A twenty-three bit number times a fourteen bit number requires
  //  a 37 bit result.
  long long int tmpResult ;
  tmpResult = tmpA * tmpB ;
  tmpResult = tmpResult & 0x0000001fffffffff ;
  
  // A 31 bit number divided by a 7 bit number requires a 31-bit value
  long int tmpC = C_in & 0x7fffffff ;
  long int tmpD = D_in & 0x0000007f ;
  long int tmpResult2 = tmpC / tmpD ;

  long long int tmpFinal = tmpResult - tmpResult2 + 10 ;
  Final_out = tmpFinal & 0x0000001f ;
}

int main()
{
  int result ;
  
  BitWidthEmulation(15, 20, 5, 6, result) ;
  printf("--- Test Case 1 ---\n") ;
  printf("A_in: %d\n", 15) ;
  printf("B_in: %d\n", 20) ;
  printf("C_in: %d\n", 5) ;
  printf("D_in: %d\n", 6) ;
  printf("result: %d\n", result) ;
  printf("\n") ;

  BitWidthEmulation(1, 2, 3, 4, result) ;
  printf("--- Test Case 2 ---\n") ;
  printf("A_in: %d\n", 1) ;
  printf("B_in: %d\n", 2) ;
  printf("C_in: %d\n", 3) ;
  printf("D_in: %d\n", 4) ;
  printf("result: %d\n", result) ;
  printf("\n") ;

  BitWidthEmulation(-1, -2, -3, -4, result) ;
  printf("--- Test Case 3 ---\n") ;
  printf("A_in: %d\n", -1) ;
  printf("B_in: %d\n", -2) ;
  printf("C_in: %d\n", -3) ;
  printf("D_in: %d\n", -4) ;
  printf("result: %d\n", result) ;
  printf("\n") ;
  
  return 0 ;
}
