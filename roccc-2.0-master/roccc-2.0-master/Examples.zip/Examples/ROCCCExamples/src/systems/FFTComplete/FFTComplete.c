/*

  This file does a full FFT Butterfly operation using all of the previous
   modules (one stage in particular).
 
*/

#include "roccc-library.h"

void FullFFT(int* A, int* B)
{
  int i ;

  // The first stage output wires and the second stage input wires
  int internalWire0 ;
  int internalWire1 ;
  int internalWire2 ;
  int internalWire3 ;  
  int internalWire4 ;
  int internalWire5 ;
  int internalWire6 ;
  int internalWire7 ;
  int internalWire8 ;
  int internalWire9 ;
  int internalWire10 ;
  int internalWire11 ;
  int internalWire12 ;
  int internalWire13 ;  
  int internalWire14 ;
  int internalWire15 ;

  // The second stage output wires and the third stage input wires

  int internalWire16 ;
  int internalWire17 ;
  int internalWire18 ;
  int internalWire19 ;
  int internalWire20 ;
  int internalWire21 ;
  int internalWire22 ;
  int internalWire23 ;  
  int internalWire24 ;
  int internalWire25 ;
  int internalWire26 ;
  int internalWire27 ;
  int internalWire28 ;
  int internalWire29 ;
  int internalWire30 ;
  int internalWire31 ;

  const int omegaRealStage1 = 10 ;
  const int omegaImagStage1 = 1 ;

  const int omegaRealStage2 = 20 ;
  const int omegaImagStage2 = 2 ;

  const int omegaRealStage3 = 30 ;
  const int omegaImagStage3 = 3 ;

  int output0 ;
  int output1 ;
  int output2 ;
  int output3 ;
  int output4 ;
  int output5 ;
  int output6 ;
  int output7 ;
  int output8 ;
  int output9 ;
  int output10 ;
  int output11 ;
  int output12 ;
  int output13 ;
  int output14 ;
  int output15 ;
  
  int N ;

  for (i = 0 ; i < N ; i+=16)
  {

    // Stage 1
    //
    // A[i] -> A[i+15] correspond to the real, imag pairs of the first eight
    //  values.
    //
    // The outputs are internalWire0-15 and represent the real, imag pairs
	//  of x0->x7
    // x0Real -> internalWire0
    // x0Imag -> internalWire1
    // x1Real -> internalWire2
    // x1Imag -> internalWire3
    // x2Real -> internalWire4
    // x2Imag -> internalWire5
    // x3Real -> internalWire6
    // x3Imag -> internalWire7
    // x4Real -> internalWire8
    // x4Imag -> internalWire9
    // x5Real -> internalWire10
    // x5Imag -> internalWire11
    // x6Real -> internalWire12
    // x6Imag -> internalWire13
    // x7Real -> internalWire14
    // x7Imag -> internalWire15
    FFTOneStage(A[i],
		A[i+1], 
		A[i+2], 
		A[i+3], 
		A[i+4], 
		A[i+5], 
		A[i+6], 
		A[i+7], 
		A[i+8], 
		A[i+9], 
		A[i+10], 
		A[i+11], 
		A[i+12], 
		A[i+13], 
		A[i+14], 
		A[i+15], 
		omegaRealStage1, 
		omegaImagStage1, 
		internalWire0, 
		internalWire1, 
		internalWire2, 
		internalWire3, 
		internalWire4, 
		internalWire5, 
		internalWire6, 
		internalWire7, 
		internalWire8, 
		internalWire9, 
		internalWire10, 
		internalWire11, 
		internalWire12, 
		internalWire13, 
		internalWire14, 
		internalWire15);

    // Perform the criss-cross butterfly connections
    //  Stage 2
    FFTOneStage(internalWire0,
		internalWire1,
		internalWire4, 
		internalWire5, 
		internalWire8,
		internalWire9,
		internalWire12,
		internalWire13,
		internalWire2,
		internalWire3,
		internalWire6,
		internalWire7,
		internalWire10,
		internalWire11,
		internalWire14,
		internalWire15,
		omegaRealStage2,
		omegaImagStage2,
		// Outputs
		internalWire16,
		internalWire17,
		internalWire18,
		internalWire19,
		internalWire20,
		internalWire21,
		internalWire22,
		internalWire23,
		internalWire24,
		internalWire25,
		internalWire26,
		internalWire27,
		internalWire28,
		internalWire29,
		internalWire30,
		internalWire31) ;
    
    // Stage 3
    FFTOneStage(internalWire16,
		internalWire17,
		internalWire24,
		internalWire25,
		internalWire20,
		internalWire21,
		internalWire28,
		internalWire29,
		internalWire18,
		internalWire19,
		internalWire26,
		internalWire27,
		internalWire22,
		internalWire23,
		internalWire30,
		internalWire31,
		omegaRealStage3,
		omegaImagStage3,
		output0,
		output1,
		output2,
		output3,
		output4,
		output5,
		output6,
		output7,
		output8,
		output9,
		output10,
		output11,
		output12,
		output13,
		output14,
		output15) ;

    B[i+0] = output0 ;
    B[i+1] = output1 ;
    B[i+2] = output2 ;
    B[i+3] = output3 ;
    B[i+4] = output4 ;
    B[i+5] = output5 ;
    B[i+6] = output6 ;
    B[i+7] = output7 ;
    B[i+8] = output8 ;
    B[i+9] = output9 ;
    B[i+10] = output10 ;
    B[i+11] = output11 ;
    B[i+12] = output12 ;
    B[i+13] = output13 ;
    B[i+14] = output14 ;
    B[i+15] = output15 ;

  }
  
}
