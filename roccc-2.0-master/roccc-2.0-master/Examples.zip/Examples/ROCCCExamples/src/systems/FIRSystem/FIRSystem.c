/*
  This file passes the FIR filter over a stream of data and sends the 
    results to an output stream.

  Be sure to compile this code with ROCCC only after you have compiled 
   the example in the FIR directory.
*/

#include "roccc-library.h"

void FIRSystem(int* A, int* B)
{
  int i ;
  int myTmp ;

  L1: for(i = 0 ; i < 100 ; ++i)
  {
    R0: FIR(A[i], A[i+1], A[i+2], A[i+3], A[i+4], myTmp) ;
    B[i] = myTmp ;
  }

}
