
void MatrixMultiplication(int** A, int** B, int*** C0)
{
  int i ;
  int j ;
  int k ;
  int currentSum ;

  for (i = 0 ; i < 10 ; ++i)
  {
    for (j = 0 ; j < 10 ; ++j)
    {
      for (k = 0 ; k < 1 ; ++k)
      {
    	currentSum = 0 ;
    	currentSum += A[i][k] * B[k][j] ;
    	currentSum += A[i][k+1] * B[k+1][j] ;
    	currentSum += A[i][k+2] * B[k+2][j] ;
    	currentSum += A[i][k+3] * B[k+3][j] ;
    	currentSum += A[i][k+4] * B[k+4][j] ;
    	currentSum += A[i][k+5] * B[k+5][j] ;
    	currentSum += A[i][k+6] * B[k+6][j] ;
    	currentSum += A[i][k+7] * B[k+7][j] ;
    	currentSum += A[i][k+8] * B[k+8][j] ;
    	currentSum += A[i][k+9] * B[k+9][j] ;
    	C0[i][j][k] = currentSum ;
      }
    }
  }
  
}
