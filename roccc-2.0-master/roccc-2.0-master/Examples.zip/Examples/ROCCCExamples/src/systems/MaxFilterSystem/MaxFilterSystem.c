/*

  This gets the maximium value on a sliding window of 3x3.  By unrolling, 
   you can control the amount of parallelism in both the X and Y direction.

*/

#include "roccc-library.h"

void MaxFilterSystem(int** window, int height, int width, int& finalOutput)
{
  int maxCol1 ;
  int maxCol2 ;
  int maxCol3 ;

  int i ;
  int j ;


  for(i = 0 ; i < height ; ++i)
  {
    for (j = 0 ; j < width ; ++j)
    {
      MAX(window[i][j], window[i][j+1], window[i][j+2], maxCol1) ;
      MAX(window[i+1][j], window[i+1][j+1], window[i+1][j+2], maxCol2) ;
      MAX(window[i+2][j], window[i+2][j+1], window[i+2][j+2], maxCol3) ;

      // Find the maximium of the three columns
      MAX(maxCol1, maxCol2, maxCol3, finalOutput) ;
    }
  }

}
