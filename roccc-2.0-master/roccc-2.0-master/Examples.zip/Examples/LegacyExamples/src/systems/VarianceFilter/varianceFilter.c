/*

  This code will determine the variance filter on 20 image frames.

  This version takes the data in a streaming fashion, with all of the 
    manipulation handled at a higher level.  The data comes in chunks of 20, 
    and is the value of a certain pixel in 20 frames.

*/

const int sizeOfInput = 1000 ;

void VarianceFilter()
{

  char inputStream[sizeOfInput] ;
  char outputStream[sizeOfInput] ;

  int i ;

  int accum ;
  int accum2 ;

  int m ;
  int xBar ;
  int sigmaSquared ;
  int finalValue ;

  const int threshold = 500 ; // Some constant value...

  // Calculate X-bar first
  for (i = 0 ; i < sizeOfInput; i+=20)
  {
    accum = inputStream[i] + inputStream[i+1] ;
    accum += inputStream[i+2] ;
    accum += inputStream[i+3] ;
    accum += inputStream[i+4] ;
    accum += inputStream[i+5] ;
    accum += inputStream[i+6] ;
    accum += inputStream[i+7] ;
    accum += inputStream[i+8] ;
    accum += inputStream[i+9] ;
    accum += inputStream[i+10] ;
    accum += inputStream[i+11] ;
    accum += inputStream[i+12] ;
    accum += inputStream[i+13] ;
    accum += inputStream[i+14] ;
    accum += inputStream[i+15] ;
    accum += inputStream[i+16] ;
    accum += inputStream[i+17] ;
    accum += inputStream[i+18] ;
    accum += inputStream[i+19] ;

    xBar = accum / 20 ;

    // Now calculate sigma squared

    accum2 = (inputStream[i] - xBar) * (inputStream[i] - xBar) ;
    accum2 += (inputStream[i+1] - xBar) * (inputStream[i+1] - xBar) ;
    accum2 += (inputStream[i+2] - xBar) * (inputStream[i+2] - xBar) ;
    accum2 += (inputStream[i+3] - xBar) * (inputStream[i+3] - xBar) ;
    accum2 += (inputStream[i+4] - xBar) * (inputStream[i+4] - xBar) ;
    accum2 += (inputStream[i+5] - xBar) * (inputStream[i+5] - xBar) ;
    accum2 += (inputStream[i+6] - xBar) * (inputStream[i+6] - xBar) ;
    accum2 += (inputStream[i+7] - xBar) * (inputStream[i+7] - xBar) ;
    accum2 += (inputStream[i+8] - xBar) * (inputStream[i+8] - xBar) ;
    accum2 += (inputStream[i+9] - xBar) * (inputStream[i+9] - xBar) ;
    accum2 += (inputStream[i+10] - xBar) * (inputStream[i+10] - xBar) ;
    accum2 += (inputStream[i+11] - xBar) * (inputStream[i+11] - xBar) ;
    accum2 += (inputStream[i+12] - xBar) * (inputStream[i+12] - xBar) ;
    accum2 += (inputStream[i+13] - xBar) * (inputStream[i+13] - xBar) ;
    accum2 += (inputStream[i+14] - xBar) * (inputStream[i+14] - xBar) ;
    accum2 += (inputStream[i+15] - xBar) * (inputStream[i+15] - xBar) ;
    accum2 += (inputStream[i+16] - xBar) * (inputStream[i+16] - xBar) ;
    accum2 += (inputStream[i+17] - xBar) * (inputStream[i+17] - xBar) ;
    accum2 += (inputStream[i+18] - xBar) * (inputStream[i+18] - xBar) ;
    accum2 += (inputStream[i+19] - xBar) * (inputStream[i+19] - xBar) ;

    sigmaSquared = accum2 / 20 ;

    // Output in chunks of 20
    if (sigmaSquared > threshold)
    {
      finalValue = 0 ;
    }
    else
    {
      finalValue = inputStream[i] ;
    }

    outputStream[i] = finalValue ;

  }

}
