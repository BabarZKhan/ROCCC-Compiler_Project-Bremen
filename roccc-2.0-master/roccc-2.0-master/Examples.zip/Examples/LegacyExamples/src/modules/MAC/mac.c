/*

  This file represents a small multiply-accumulate component.

*/

typedef struct
{
  int num1_in ;
  int num2_in ;
  int num3_in ;

  int sum_out ;

} MAC_t ;

MAC_t MAC(MAC_t m)
{
  m.sum_out = (m.num1_in * m.num2_in) + m.num3_in ;
  return m ;
}
