/*

  This is the basic block for the FFT.  It takes two numbers (each of which 
    has a real and imaginary part) and an omega that is different at each
    stage in the butterfly.

*/

typedef struct
{
  // Inputs
  int realOne_in ;
  int imagOne_in ;
  int realTwo_in ;
  int imagTwo_in ;
  int realOmega_in ;
  int imagOmega_in ;
  
  // Outputs 
  int A0_out ;
  int A1_out ;
  int A2_out ;
  int A3_out ;

} FFT_t ;

FFT_t FFT(FFT_t f)
{

  f.A0_out = f.realOne_in + (f.realOmega_in * f.realTwo_in) - 
            (f.imagOmega_in * f.imagTwo_in) ;

  f.A1_out = f.imagOne_in + (f.realOmega_in * f.imagTwo_in) + 
            (f.imagOmega_in * f.realTwo_in) ;

  f.A2_out = f.realOne_in - (f.realOmega_in * f.realTwo_in) + 
            (f.imagOmega_in * f.imagTwo_in) ;

  f.A3_out = f.imagOne_in - (f.realOmega_in * f.imagTwo_in) - 
            (f.imagOmega_in * f.realTwo_in) ;

  return f ;
}
