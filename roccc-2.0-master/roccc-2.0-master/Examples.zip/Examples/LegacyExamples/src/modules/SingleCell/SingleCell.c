
typedef int ROCCC_int2 ;
typedef int ROCCC_int8 ;

typedef struct
{
  ROCCC_int8 S_in ;
  ROCCC_int8 T_in ;
  ROCCC_int8 upper_in ;
  ROCCC_int8 upperLeft_in ;
  ROCCC_int8 left_in ;

  ROCCC_int8 current_out ;
} SingleCell_t ;

SingleCell_t SingleCell(SingleCell_t t)
{
  const int matchCost = 4 ;
  const int mismatchCost = 3 ;
  const int insertCost = 2 ;
  const int deleteCost = 1 ;

  ROCCC_int8 intermediate0 ;
  ROCCC_int8 intermediate1 ;

  if (t.S_in == t.T_in)
  {
    intermediate0 = t.upperLeft_in + matchCost ;
  }
  else
  {
    intermediate0 = t.upperLeft_in + mismatchCost ;
  }

  if (t.upper_in + insertCost > t.left_in + deleteCost)
  {
    intermediate1 = t.upper_in + insertCost ;
  }
  else
  {
    intermediate1 = t.left_in + deleteCost ;
  }

  if (intermediate0 > intermediate1)
  {
    t.current_out = intermediate0 ;
  }
  else
  {
    t.current_out = intermediate1 ;
  }

  return t ;
  
}

