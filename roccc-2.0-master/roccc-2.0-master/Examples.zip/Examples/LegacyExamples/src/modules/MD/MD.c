/*
  This file contains a hardware module that performs a subset of the 
   calculations necessary for a single timestep in molecular dynamics
   simulations.  Two atom's data are passed in and the Coulombic force
   in the X, Y, and Z direction are calculated.
*/

typedef struct
{
  int atomOneCurrentX_in ;
  int atomOneCurrentY_in ;
  int atomOneCurrentZ_in ;
  int atomOneCurrentCharge_in ;

  int atomTwoCurrentX_in ;
  int atomTwoCurrentY_in ;
  int atomTwoCurrentZ_in ;
  int atomTwoCurrentCharge_in ;

  int tableLookup_in ;
  
  int CoulombicForceX_out ;
  int CoulombicForceY_out ;
  int CoulombicForceZ_out ;

} MD_t ;

MD_t MD(MD_t m)
{
  int twelfthTerm ;
  int sixthTerm ;
  int radiusToTheTwelfth ;
  int radiusToTheSixth ;
  int radiusSquared ;
  int distanceXSquared ;
  int distanceYSquared ;
  int distanceZSquared ;
  int differenceX ;
  int differenceY ;
  int differenceZ ;
  int vcoul ;
  int rinvsq ;
  int rinv ;

  differenceX = m.atomOneCurrentX_in - m.atomTwoCurrentX_in ;
  differenceY = m.atomOneCurrentY_in - m.atomTwoCurrentY_in ;
  differenceZ = m.atomOneCurrentZ_in - m.atomTwoCurrentZ_in ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;

  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  
  rinv = (m.tableLookup_in * (((radiusSquared * m.tableLookup_in) * m.tableLookup_in))) ;

  vcoul = m.atomOneCurrentCharge_in * m.atomTwoCurrentCharge_in * rinv ;

  rinvsq = rinv * rinv ;

  m.CoulombicForceX_out = vcoul * rinvsq * differenceX ;
  m.CoulombicForceY_out = vcoul * rinvsq * differenceY ;
  m.CoulombicForceZ_out = vcoul * rinvsq * differenceZ ;

  return m ;
}
