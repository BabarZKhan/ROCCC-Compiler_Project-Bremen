#include "roccc-library.h"

typedef float ROCCC_float32 ;
typedef int ROCCC_int1 ;

typedef struct
{
  // Inputs
  ROCCC_float32 a_in ;
  ROCCC_float32 b_in ;
  ROCCC_float32 c_in ;

  // Outputs
  ROCCC_float32 x1Real_out ;
  ROCCC_float32 x1Imag_out ;
  ROCCC_float32 x2Real_out ;
  ROCCC_float32 x2Imag_out ;
  
  ROCCC_int1 infinity_out ;
} QuadraticFormula_t ;

QuadraticFormula_t QuadraticFormula(QuadraticFormula_t t)
{
  ROCCC_float32 sqrtValue ;
  ROCCC_float32 bSquaredMinusFourAC ;
  ROCCC_float32 twoA ;

  ROCCC_float32 tempReal1 ;
  ROCCC_float32 tempImag1 ;
  ROCCC_float32 tempReal2 ;
  ROCCC_float32 tempImag2 ;

  ROCCC_int1 tempInfinity ;

  // If A is zero, it is not quadratic thus you get division by zero
  if (t.a_in == 0)
  {
    tempReal1 = 0 ;
    tempImag1 = 0 ;
    tempReal2 = 0 ; 
    tempImag2 = 0 ;

    tempInfinity = 1 ;
  }
  else
  {
    bSquaredMinusFourAC = t.b_in * t.b_in - 4 * t.a_in * t.c_in ;
    twoA = 2 * t.a_in ;
    
    // If the inside of the square root is negative, then you get
    //  imaginary numbers
    if (bSquaredMinusFourAC >= 0)
    {
      SQRT(bSquaredMinusFourAC, sqrtValue) ; // SQRT must exist in the database
      
      tempReal1 = -t.b_in + sqrtValue / twoA ;
      tempReal2 = -t.b_in - sqrtValue / twoA ;

      tempImag1 = 0 ;
      tempImag2 = 0 ;
    }
    else
    {
      tempReal1 = -t.b_in / twoA ;
      tempReal2 = tempReal1 ;

      SQRT(-bSquaredMinusFourAC, sqrtValue) ;
      
      tempImag1 = sqrtValue / twoA ;
      tempImag2 = -tempImag1 ;
    }
    tempInfinity = 0 ;
  }

  t.x1Real_out = tempReal1 ;
  t.x1Imag_out = tempImag1 ;
  t.x2Real_out = tempReal2 ;
  t.x2Imag_out = tempImag2 ;

  t.infinity_out = tempInfinity ;

  return t ;
}
