/*

  This example exists only to show that modules can have loops if they
   are fully unrolled.

*/

typedef struct
{
  int x_in ;

  int y_out ;
} LoopTest_t ;

LoopTest_t LoopTest(LoopTest_t t)
{
  int i ;
  int currentSum ;
  int A[10] ;
  
  currentSum = 0 ;

 L1: for (i = 0 ; i < 10 ; ++i)
  {
    A[i] = i ;
  }

 L2: for (i = 0 ; i < 10 ; ++i)
  {
    if (t.x_in == A[i])
    {
      currentSum = currentSum + A[i] ;
    }
    else
    {
      currentSum = currentSum + 1 ;
    }
  }
  
  t.y_out = currentSum + t.x_in ;

  return t ;
}
