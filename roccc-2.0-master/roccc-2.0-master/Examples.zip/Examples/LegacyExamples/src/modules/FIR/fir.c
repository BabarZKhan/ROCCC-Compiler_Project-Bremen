/*

  A five-tap FIR filter.  

*/

typedef struct
{
  // Inputs
  int A0_in ;
  int A1_in ;
  int A2_in ;
  int A3_in ;
  int A4_in ;

  // Outputs
  int result_out ;

} FIR_t ;

FIR_t FIR(FIR_t f)
{
  // Should be propagated
  const int T[5] = { 3, 5, 7, 9, 11 } ;

  f.result_out = f.A0_in * T[0] +
    f.A1_in * T[1] +
    f.A2_in * T[2] +
    f.A3_in * T[3] +
    f.A4_in * T[4] ;

  return f ;
}
