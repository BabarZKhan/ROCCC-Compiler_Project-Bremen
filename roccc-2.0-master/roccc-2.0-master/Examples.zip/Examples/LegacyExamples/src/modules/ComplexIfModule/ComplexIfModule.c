/*
  This example requires the MAX module.  This example shows some of the 
   types of if statements supported by ROCCC 2.0.
*/

#include "roccc-library.h"

typedef struct
{
  int x_in ;
  int y_in ;
  int z_in ;

  int final_out ;
} ComplexIfModule_t ;

ComplexIfModule_t ComplexIfModule(ComplexIfModule_t t)
{
  int temp ;
  int temp2 ;

  if (t.x_in != t.y_in)
  {
    temp = t.z_in ;
    temp = temp + 5 ;
  }
  else
  {
    if (t.z_in == 15)
    {
      MAX(t.x_in, t.y_in, t.z_in, temp2) ;
    }
    else
    {
      MAX(t.y_in, t.z_in, t.x_in, temp2) ;
    }
  }

  t.final_out = temp + temp2 ;
  return t ;
}
